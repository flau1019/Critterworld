# Critter World

See the [project specification](http://www.cs.cornell.edu/courses/cs2112/2024fa/project/project.pdf).

## A4
See the [A4 writeup](http://www.cs.cornell.edu/courses/cs2112/2024fa/hw/a4/a4.pdf) 
