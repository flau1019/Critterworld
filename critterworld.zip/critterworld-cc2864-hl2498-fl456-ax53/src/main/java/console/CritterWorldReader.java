package console;

import ast.Program;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import exceptions.SyntaxError;
import model.Critter;
import model.CritterWorldImpl;
import parse.Parser;
import parse.ParserFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class in charge of reading in critter and world data from a file.
 */
public class CritterWorldReader {
    /**
     * Returns a critter from the critter file at the specified location.
     * If there is an error while reading the file (IOException or incorrectly
     * formatted file), prints the exception to the console and returns a default
     * critter instead.
     * Extra integers on a line that expects a fixed amount of integers will be ignored. For
     * example, inputting "defense 1 2" will set the defense to 1 and discard the extra value 2.
     * @param fileName the critter file location.
     * @return a critter constructed from fileName, or a default critter if an exception occurred.
     */
    public static Critter readCritter(String fileName) {
        File f = new File(fileName);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)))) {
            return readCritter(f, br);
        } catch (IOException | SyntaxError e) {
            System.out.println(e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Critter data must be in integer form");
        }
        return new Critter();
    }

    /**
     * Helper method to read a critter. Attempts to read and construct a critter and
     * throws exceptions if something goes wrong.
     * Extra integers on a line that expects a fixed amount of integers will be ignored. For
     * example, inputting "size 1 2 3" will set the width to 1 and height to 2, and discard
     * the extra value 3.
     * @param f the critter file.
     * @param br reader for the critter file.
     * @return a new critter constructed from the given file.
     * @throws IOException if an I/O exception occurred.
     * @throws SyntaxError if critter program is invalid.
     * @throws NumberFormatException if integer critter data is formatted incorrectly.
     */
    private static Critter readCritter(File f, BufferedReader br) throws IOException, IllegalArgumentException, SyntaxError, NumberFormatException {
        String species = "Critter";
        int memsize=0, defense=0, offense=0, size=0, energy=0, posture=0;
        Program program = null;

        String line;
        do {
            line = br.readLine();
        } while (line != null && trimLine(line).isEmpty());
        if (line == null) {
            System.out.println("Parameters for critter were missing.");
            return new Critter();
        }
        line = trimLine(line);
        if (line.length() <= 9 || !line.startsWith("species: ")) {
            System.out.println("Must specify a species name for critter using the format: species: <name>");
        } else {
            species = line.substring(9);
        }

        try {
            memsize = extractNextInt(br, "memsize:", "memsize").get();
            defense = extractNextInt(br, "defense:", "defense").get();
            offense = extractNextInt(br, "offense:", "offense").get();
            size = extractNextInt(br, "size:", "size").get();
            energy = extractNextInt(br, "energy:", "energy").get();
            posture = extractNextInt(br, "posture:", "posture").get();
        } catch (NoMaybeValue ignored) {
            // exception output is already printed to the user through extractNextInt
        }

        Parser parser = ParserFactory.getParser();
        try {
            program = parser.parse(br);
        } catch (SyntaxError e) {
            System.out.println(e.getMessage());
        }
        return new Critter(species, memsize, defense, offense, size, energy, posture, program);
    }

    /**
     * Returns a world constructed from the world file at the specified location.
     * If there is an error while reading the file (IOException or incorrectly
     * formatted file), prints the exception to the console and returns a default
     * world instead.
     * @param fileName the world file location.
     * @param enableManna if enableManna is false, then the world will not drop any manna.
     * @param enableForcedMutation if enableForcedMutation is true, then a critter's program
     * will mutate every time it finishes its action.
     * @return a world constructed from fileName, or a default world if an exception occurred.
     */
    public static CritterWorldImpl readWorld(String fileName, boolean enableManna, boolean enableForcedMutation) {
        File f = new File(fileName);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)))) {
            return readWorld(f, br, enableManna, enableForcedMutation);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("World data must be in integer form");
        }
        return new CritterWorldImpl(); //default 10x10 world
    }

    /**
     * Helper method to read a world. Attempts to read and construct a world and
     * throws exceptions if something goes wrong.
     * @param f the world file.
     * @param br reader for the world file.
     * @param enableManna if enableManna is false, then the world will not drop any manna.
     * @param enableForcedMutation if enableForcedMutation is true, then a critter's program
     * will mutate every time it finishes its action.
     * @return a new world constructed from the given file.
     * @throws IOException if an I/O exception occurred.
     * @throws NumberFormatException if integer world data is formatted incorrectly.
     */
    private static CritterWorldImpl readWorld(File f, BufferedReader br, boolean enableManna, boolean enableForcedMutation) throws IOException, NumberFormatException {
        String name = "New World";
        int width = 0, height = 0;

        String line;
        do {
            line = br.readLine();
        } while (line != null && trimLine(line).isEmpty());
        if (line == null) {
            System.out.println("Parameters for world were missing.");
            return new CritterWorldImpl(name, width, height, enableManna, enableForcedMutation);
        }
        line = trimLine(line);
        if (line.length() <= 5 || !line.startsWith("name ")) {
            System.out.println("Must specify a name for the world using the format: name <world name>");
        } else {
            name = line.substring(5);
        }

        try {
            List<Integer> dims = extractNextInts(br, "size").get();
            if (dims.size() >= 2) {
                width = dims.get(0);
                height = dims.get(1);
            } else {
                throw new NoMaybeValue();
            }
        } catch (NoMaybeValue e) {
            System.out.println("Must specify dimensions for the world using the format: size <width> <height>");
        }

        CritterWorldImpl world = new CritterWorldImpl(name, width, height, enableManna, enableForcedMutation);

        String lineRaw = br.readLine();
        String[] params;
        while (lineRaw != null) {
            line = trimLine(lineRaw);
            lineRaw = br.readLine();
            if (line.isBlank()) {
                continue;
            }
            params = line.split(" ");
            int c, r, food, dir;
            switch(params[0]) {
                case "rock":
                    if (params.length >= 3) {
                        c = Integer.parseInt(params[1]);
                        r = Integer.parseInt(params[2]);
                        world.addRocks(c, r);
                    } else {
                        System.out.println("Specify position of a rock using this format: rock <column> <row>");
                    }
                    break;
                case "food":
                    if (params.length >= 4) {
                        c = Integer.parseInt(params[1]);
                        r = Integer.parseInt(params[2]);
                        food = Integer.parseInt(params[3]);
                        world.addFood(c, r, food);
                    } else {
                        System.out.println("Specify position of a food using this format: food <column> <row> <amount>");
                    }
                    break;
                case "critter":
                    if (params.length >= 5) {
                        String file = f.getParent() + File.separator + params[1];

                        Critter critter = readCritter(file);
                        c = Integer.parseInt(params[2]);
                        r = Integer.parseInt(params[3]);
                        dir = Integer.parseInt(params[4]);
                        world.addCritter(critter, c, r, dir);
                    } else {
                        System.out.println("Specify position of a critter using this format: critter <critter file> <column> <row> <direction>");
                    }
                    break;
                default:
                    System.out.println("Objects in world must be one of rock, food, or critter:\nrock <column> <row>\nfood <column> <row> <amount>\ncritter <critter file> <column> <row> <direction>");
            }
        }
        if (world.isEmpty()) {
            world.randomPopulation();
        }
        return world;
    }

    /**
     * Helper method to capture a regex from the next line of a file.
     * @param p regex pattern.
     * @param br file to read from.
     * @return the captured regex using Matcher.group();
     * @throws IOException if I/O exception occurred.
     */
    private static String readLine(Pattern p, BufferedReader br) throws IOException {
        Matcher m = p.matcher(br.readLine());
        return m.group();
    }

    /**
     * Remove comments (anything starting with //) and trailing whitespace from a string on a single line.
     * @param s string to trim.
     * @return the string with comments and trailing whitespace removed.
     */
    private static String trimLine(String s) {
        String[] noComment= s.split("//");
        if (noComment.length == 0) {
            return "";
        }
        return noComment[0].trim();
    }

    /**
     * Returns a Maybe.some() containing a list of all the integers present on the next non-comment
     * and non-whitespace line that starts with the phrase contained in label. If the next
     * non-comment/whitespace line on the BufferedReader does not start with label, return
     * Maybe.none().
     * @param br file to read lines from.
     * @param label line containing ints must start with label and be separated by spaces.
     * @return Maybe.some() containing the ints present on the specified line, or Maybe.none()
     * if line was not found.
     * @throws IOException if an I/O exception occurred.
     * @throws NumberFormatException if a non-integer value was given on the line (excluding
     * the initial label at the start).
     */
    private static Maybe<List<Integer>> extractNextInts(BufferedReader br, String label) throws IOException, NumberFormatException {
        String[] spaceSplit = new String[0];
        while (spaceSplit.length == 0 || (spaceSplit.length == 1 && spaceSplit[0].isBlank())) {
            String s = br.readLine();
            if (s == null) {
                return Maybe.none();
            }
            spaceSplit = trimLine(s).split(" ");
        }
        if (!spaceSplit[0].equals(label)) {
            System.out.println("Expected line starting with \"" + label + "\" but was \"" + spaceSplit[0] + "\" instead");
            return Maybe.none();
        }
        List<Integer> nums = new ArrayList<>();
        for (int i = 1; i < spaceSplit.length; i++) {
            try {
                nums.add(Integer.parseInt(spaceSplit[i]));
            } catch (NumberFormatException ignored) { }
        }
        return Maybe.some(nums);
    }

    /**
     * Similar to extractNextInts, but discards all integers following the first int to be found.
     * If there were no ints found, returns -1 and does not move onto the next line.
     * @param br file to read lines from.
     * @param label line containing ints must start with label and be separated by spaces.
     * @param labelname name of label (used to format the error message printed to the user)
     * @return Maybe.some() containing the first int present on the specified line, or Maybe.none()
     * if line/integer was not found.
     * @throws IOException if an I/O exception occurred or if too much data is present on one line.
     */
    private static Maybe<Integer> extractNextInt(BufferedReader br, String label, String labelname) throws IOException {
        try {
            br.mark(1000);
            return Maybe.some(extractNextInts(br, label).get().getFirst());
        } catch (NoMaybeValue | NoSuchElementException e) {
            System.out.println("No value was given for " + labelname);
            br.reset();
            return Maybe.some(-1);
        } catch (NumberFormatException ignored) {}
        return Maybe.none();
    }
}
