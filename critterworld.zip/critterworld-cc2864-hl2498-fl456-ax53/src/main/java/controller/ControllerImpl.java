package controller;

import console.CritterWorldReader;
import model.Critter;
import model.CritterWorldImpl;
import model.ReadOnlyWorld;
import ast.*;

import java.io.PrintStream;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ControllerImpl implements Controller {
    CritterWorldImpl world;

    @Override
    public void newWorld() {
        world = new CritterWorldImpl();
    }

    @Override
    public boolean loadWorld(String filename, boolean enableManna, boolean enableForcedMutation) {
        try{
            world = CritterWorldReader.readWorld(filename, enableManna, enableForcedMutation);
            return true;
        } catch (Exception e){
            e.getMessage();
            return false;
        }
    }

    @Override
    public boolean loadCritters(String filename, int n) {
        Random random = new Random();
        Critter critter;
        try {
            critter = CritterWorldReader.readCritter(filename);
        } catch (Exception e) {
            return false;
        }

        for(int i = 0; i < n; i++) {
            int height = random.nextInt(1, world.getMapRow());
            int width = random.nextInt(1, world.getMapCol());
            int direction = random.nextInt(0, 5);
            world.addCritter(critter, width, height, direction);
        }

        return true;
    }

    @Override
    public boolean advanceTime(int n) {
        for (int i = 0; i < n; i++) {
            world.getActiveCritters().get(i).runProgram();
            world.nextIteration();
        }
        return true;
    }

    @Override
    public ReadOnlyWorld getReadOnlyWorld() {
        return world.readOnly();
    }

    @Override
    public void printWorld(PrintStream out) {
        Object[][] map = world.getMap();
        for(int i = world.getInputRow(); i > 0; i--) { //row
            StringBuilder line = new StringBuilder();
            int a;
            if(i % 2 == 0) {
                a = 1;
                line.append("  ");
            }
            else {
                a = 0;
            }
            for(int j = a; j < world.getMapCol(); j += 2) {
                if(((Optional) map[((i-1)/2)][j]).isEmpty()){
                    line.append("-   ");
                }
                else if(((Optional) map[((i-1)/2)][j]).get() instanceof Critter){
                    Critter critter = ((Critter) ((Optional) map[((i-1)/2)][j]).get());
                    line.append(critter.getPosture() + "   ");
                }
                else if(((Optional) map[((i-1)/2)][j]).get().equals(-1)) {
                    line.append("#   ");
                }
                else if((Integer) ((Optional) map[((i-1)/2)][j]).get() < -1){
                    line.append("F   ");
                }
            }
            out.println(line);
        }
    }

//    public void arraytohex(int[][] world) {
//          int row = 15;
//
//        for(int i = row; i > 0; i--) { //row
//            StringBuilder line = new StringBuilder();
//            int a;
//            if(i % 2 == 0) {
//                a = 1;
//                line.append(" ");
//            }
//            else {
//                a = 0;
//            }
//            for(int j = a; j < 10; j += 2) { //col
//                line.append(world[((i-1)/2)][j] + " ");
//            }
//            System.out.println(line);
//        }
//
//    }

    public CritterWorldImpl getWorld(){
        return world;
    }
}
