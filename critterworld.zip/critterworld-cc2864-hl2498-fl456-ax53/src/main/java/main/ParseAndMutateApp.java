package main;


import ast.Program;
import exceptions.SyntaxError;
import parse.Parser;
import parse.ParserFactory;

import java.io.*;

public class ParseAndMutateApp {

    public static void main(String[] args) {
        int n = 0;
        String file = null;
        try {

            // read from console
            if (args.length == 1) {
                file = args[0];
            }
            else if (args.length == 3 && args[0].equals("--mutate")) {
                n = Integer.parseInt(args[1]);
                if (n < 0) throw new IllegalArgumentException();
                file = args[2];
            }
            else {
                throw new IllegalArgumentException();
            }

            // try to read file and parse
            Parser parser = ParserFactory.getParser();
            Reader reader;
            try {
                InputStream in = new FileInputStream(file);
                reader = new InputStreamReader(in);
            } catch (Exception e){
                throw new FileNotFoundException();
            }
            Program p = parser.parse(reader);
            // perform mutate
            for (int i = 0; i < n; i++) {
                Program p0 = (Program) p.clone();
                while (p0.equals(p)){
                    p = p.mutate();
                }
            }
            System.out.println(p.toString());
        }
        catch (IllegalArgumentException e) {
            System.out.println("Usage:\n  <input_file>\n  --mutate <n> <input_file>");
        }
        catch (FileNotFoundException e) {
            System.out.println("Input file not found or unsupported.");
        }
        catch (SyntaxError e) {
            System.out.println("Syntax error.");
        }
    }
}
