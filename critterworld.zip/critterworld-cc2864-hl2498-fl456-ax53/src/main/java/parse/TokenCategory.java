package parse;

/** Type of token representing a terminal in the critter language. */
public enum TokenCategory {
    ACTION,
    BINOP,
    RELOP,
    ADDOP,
    MULOP,
    SENSOR,
    MEMSUGAR,
    OTHER,
}
