package parse;

import ast.*;
import exceptions.SyntaxError;

import java.io.Reader;
import java.util.ArrayList;


class ParserImpl implements Parser {

    @Override
    public Program parse(Reader r) throws SyntaxError {
        Tokenizer t = new Tokenizer(r);
        return parseProgram(t);
    }


    /**
     * Parses a program from the stream of tokens provided by the Tokenizer, consuming tokens
     * representing the program. All following methods with a name {@code parseX} have the same spec
     * except that they parse syntactic form X.
     *
     * @param t the tokenizer
     * @return the created AST
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static ProgramImpl parseProgram(Tokenizer t) throws SyntaxError {
        ProgramImpl program = new ProgramImpl(new ArrayList<>());
        while (t.hasNext()) {
            Rule r = parseRule(t, program);
            program.getChildren().add(r);
            if (t.peek().getType().equals(TokenType.SEMICOLON)) {
                consume(t, TokenType.SEMICOLON);
            }
        }
        // throw error if the input file is empty
        if (program.toString().isEmpty()) throw new SyntaxError(0, "Empty program");
        return program;
    }

    /**
     * Parse a single rule from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return the parsed rule
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static Rule parseRule(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractBinaryBool b = parseBool(t, p);

        ArrayList<Node> commands = new ArrayList<>();
        if(t.peek().getType().equals(TokenType.ARR)) {
            consume(t, TokenType.ARR);
            int NumAction = 0;
            while (t.peek().isMemSugar() || t.peek().isAction() || t.peek().getType().equals(TokenType.MEM)) {
                if(t.peek().isMemSugar()|| t.peek().getType().equals(TokenType.MEM)) {
                    BinaryUpdate update = parseUpdate(t, p);
                    commands.add(update);
                }
                else {
                    NumAction++;
                    if (NumAction > 1) {
                        throw new SyntaxError(t.lineNumber(), "Invalid syntax for rule - commands expected");
                    }
                    Action action = parseAction(t, p);
                    commands.add(action);
                }
            }
        }
        if (commands.isEmpty()) {
            throw new SyntaxError(t.lineNumber(), "Invalid syntax for rule, must contain at least one command");
        }
        Rule rule = new Rule (b, commands);
        rule.setParent(p);
        p.addNode(rule);
        return rule;
    }

    /**
     * Parse a boolean expression from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return the parsed boolean expression
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractBinaryBool parseBool(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractBinaryBool left = parseAnd(t, p);
        if(t.peek().getType().equals(TokenType.OR)) {
            consume(t, TokenType.OR);
            AbstractBinaryBool right = parseBool(t, p);
            BinaryOp orNode = new BinaryOp(TokenType.OR, left, right);

            p.addNode(orNode);
            return orNode;
        }
        return left;
    }

    /**
     * Parse a boolean expression of the form "BOOLEAN and BOOLEAN" from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a boolean expression of the form "BOOLEAN and BOOLEAN"
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractBinaryBool parseAnd(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractBinaryBool left = parseB(t, p);
        if(t.peek().getType().equals(TokenType.AND)) {
            consume(t, TokenType.AND);

            AbstractBinaryBool right = parseAnd(t, p);
            BinaryOp andNode =  new BinaryOp(TokenType.AND, left, right);
            p.addNode(andNode);
            return andNode;
        }
        return left;
    }

    /**
     * Parse either a boolean expression in parentheses or a binary relation from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return either a boolean expression in parentheses or a binary relation
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractBinaryBool parseB(Tokenizer t, ProgramImpl p) throws SyntaxError {
        if (t.peek().getType().equals(TokenType.LBRACE)) {
            consume(t, TokenType.LBRACE);
            AbstractBinaryBool b = parseBool(t, p);
            consume(t, TokenType.RBRACE);
            return b;
        } else {
            return parseRel(t, p);
        }
    }

    /**
     * Parse a binary relation from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a binary relation
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static BinaryRel parseRel(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractExpr e = parseExpression(t, p);

        TokenType token = t.peek().getType();

        if (token.category().equals(TokenCategory.RELOP)){
            consume(t, token);
            AbstractExpr e2 = parseExpression(t, p);
            BinaryRel relNode = new BinaryRel(token, e, e2);
            p.addNode(relNode);
            return relNode;
        }
        else{
            throw new SyntaxError(t.lineNumber(), "no such binary operator");
        }
    }


    /**
     * Parse a memory update from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a memory update
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static BinaryUpdate parseUpdate(Tokenizer t, ProgramImpl p) throws SyntaxError {
        MemGet g = parseMem(t, p);
        consume(t, TokenType.ASSIGN);
        AbstractExpr e = parseExpression(t, p);
        BinaryUpdate updateNode = new BinaryUpdate(g, e);

        p.addNode(updateNode);
        return updateNode;
    }

    /**
     * Parse a numerical expression (add, minus) from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a numerical expression
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractExpr parseExpression(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractExpr left = parseT(t, p);
        TokenType op = t.peek().getType();

        while(op.category().equals(TokenCategory.ADDOP)) {
            consume(t, op);

            AbstractExpr right = parseT(t, p);
            left = new BinaryNumeric(op, left, right);

            p.addNode(left);
            op = t.peek().getType();
        }
        return left;
    }

    /**
     * Parse a numerical expression (mul, div, mod) from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a numerical expression
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractExpr parseT(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractExpr e = parseF(t, p);

        TokenType token = t.peek().getType();

        while (token.category().equals(TokenCategory.MULOP)){
            consume(t, token);
            AbstractExpr e2;
            if (t.peek().getType().equals(TokenType.LPAREN)) {
                consume(t, TokenType.LPAREN);
                e2 = parseExpression(t, p);
                consume(t, TokenType.RPAREN);
            } else {
                e2 = parseF(t, p);
            }
            BinaryNumeric numNode = new BinaryNumeric(token, e, e2);
            e = numNode;
            p.addNode(numNode);
            token = t.peek().getType();
        }
        return e;
    }

    /**
     * Parse a numerical expression (number value or expression in parentheses) from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a numerical expression (number value or expression in parentheses)
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractExpr parseF(Tokenizer t, ProgramImpl p) throws SyntaxError {
        AbstractExpr numNode;
        TokenType token = t.peek().getType();

        if(t.peek().isNum() || t.peek().isSensor() || token.category().equals(TokenCategory.MEMSUGAR) || token.equals(TokenType.MEM)) {
            numNode = parseValue(t, p);
        } else if (token.equals(TokenType.LPAREN)) {
            consume(t, TokenType.LPAREN);
            numNode = parseExpression(t, p);
            consume(t, TokenType.RPAREN);
        } else if (token.equals(TokenType.MINUS)) {
            consume(t, TokenType.MINUS);
            numNode = new UnaryNumeric(parseF(t, p));
        } else {
            throw new SyntaxError(t.lineNumber(), "Invalid factor - expected expression, number, or memory reference. Recieved: " + token);
        }
        return numNode;
    }

    /**
     * Parse a numerical value (number, sensor, or memory address) from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a numerical value (number, sensor, or memory address)
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractExpr parseValue(Tokenizer t, ProgramImpl p) throws SyntaxError {
        TokenType token = t.peek().getType();
        if (t.peek().isNum() || t.peek().getType().equals(TokenType.MINUS)) {
            return parseNumeric(t, p);
        } else if (t.peek().isSensor()) {
            return parseSensor(t, p);
        } else if (token.category().equals(TokenCategory.MEMSUGAR)|| token.equals(TokenType.MEM)) {
            return parseMem(t, p);
        } else {
            throw new SyntaxError(t.lineNumber(), "Invalid value type in expression");
        }
    }

    /**
     * Parse a number from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a number
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static AbstractExpr parseNumeric(Tokenizer t, ProgramImpl p) throws SyntaxError {
        int value = 1;
        TokenType token = t.peek().getType();
        if (token.equals(TokenType.MINUS)) {
            value = -1;
            consume(t, TokenType.MINUS);
        }
        if (!t.peek().isNum()) {
            throw new SyntaxError(t.lineNumber(), "Expected a numeric value after sign");
        }

        value *= (Integer.parseInt(String.valueOf(t.peek())));
        consume(t, TokenType.NUM);
        Numeric numNode = new Numeric(value);
        p.addNode(numNode);
        return numNode;
    }


    /**
     * Parse a sensor value from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a sensor value
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static Sensor parseSensor(Tokenizer t, ProgramImpl p) throws SyntaxError {
        TokenType sensor = t.peek().getType();
        if (t.peek().isSensor()) {
            if (!t.peek().getType().equals(TokenType.SMELL)){
                consume(t, sensor);
                consume(t, TokenType.LBRACKET);
                AbstractExpr e = parseExpression(t, p);
                consume(t, TokenType.RBRACKET);
                Sensor sensorNode = new Sensor(sensor, e);
                p.addNode(sensorNode);
                return sensorNode;
            }
            else {
                consume(t, sensor);
                Sensor sensorNode = new Sensor(sensor);
                p.addNode(sensorNode);
                return sensorNode;
            }
        }
        throw new SyntaxError(t.lineNumber(), "invalid sensor name");
    }

    /**
     * Parse a memory address from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return a memory address
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static MemGet parseMem(Tokenizer t, ProgramImpl p) throws SyntaxError {
        TokenType token = t.peek().getType();

        if (token.equals(TokenType.MEM)) {
            // standard MEM access with brackets, e.g. mem[9]
            consume(t, TokenType.MEM);
            consume(t, TokenType.LBRACKET);
            AbstractExpr e = parseExpression(t, p);
            consume(t, TokenType.RBRACKET);
            MemGet memNode = new MemGet(e);
            p.addNode(memNode);
            return memNode;
        } else if (token.category().equals(TokenCategory.MEMSUGAR)){
            //handles syntactic sugars MEMSUGAR, e.g. POSTURE -> memget[6]
            try {
                int index = getMemdex (token);
                Numeric num = new Numeric(index);
                MemGet memNode = new MemGet (num);
                p.addNode(memNode);
                p.addNode(num);
                consume(t, token);
                return memNode;
            } catch (IllegalArgumentException e) {
                throw new SyntaxError(t.lineNumber(), e.getMessage());
            }
        }
        throw new SyntaxError(t.lineNumber(), "invalid expression in mem[]");
    }

    /**
     * Parse an action from the string of tokens provided by the Tokenizer.
     * @param t the tokenizer
     * @param p the critter program to add the rule to
     * @return an action
     * @throws SyntaxError if the input tokens have invalid syntax
     */
    public static Action parseAction(Tokenizer t, ProgramImpl p) throws SyntaxError {
        TokenType action = t.peek().getType();
        Action actionNode;
        if(t.peek().isAction()) {
            if (t.peek().getType().equals(TokenType.SERVE)){
                consume(t, action);
                consume(t, TokenType.LBRACKET);
                AbstractExpr e = parseExpression(t, p);
                consume(t, TokenType.RBRACKET);
                actionNode = new Action(action, e);

                p.addNode(actionNode);
            } else{
                consume(t, action);
                actionNode = new Action(action);

                p.addNode(actionNode);
            }
            return actionNode;
        }
        throw new SyntaxError(t.lineNumber(), "action does not exist");
    }

    /**
     * Consumes a token of the expected type.
     *
     * @throws SyntaxError if the wrong kind of token is encountered.
     */
    public static void consume(Tokenizer t, TokenType tt) throws SyntaxError {
        if(t.peek().getType().equals(tt)){
            t.next();
        }
        else {
            throw new SyntaxError(t.lineNumber(), "TokenType " + tt + " was not found. Next element: " + t.peek());
        }
    }

    /**
     * Returns the mem index corresponding to the given syntactic sugar.
     * <p>Requires: t is a syntactic sugar type.
     * @param t token for a syntactic sugar.
     * @return mem index corresponding to t.
     */
    private static int getMemdex(TokenType t){
        switch (t){
            case ABV_MEMSIZE -> {
                return 0;
            }
            case ABV_DEFENSE -> {
                return 1;
            }
            case ABV_OFFENSE -> {
                return 2;
            }
            case ABV_SIZE -> {
                return 3;
            }
            case ABV_ENERGY -> {
                return 4;
            }
            case ABV_PASS -> {
                return 5;
            }
            case ABV_POSTURE -> {
                return 6;
            }
            default -> throw new IllegalArgumentException("Unknown MEMSUGAR type: " + t);
        }
    }
}
