package ast;

import parse.TokenCategory;
import parse.TokenType;

import java.util.List;

/**
 * Represents a mathematical expression that returns a numeric value.
 */
public class BinaryNumeric extends AbstractExpr{

    /**
     * Create an AST representation of lhs op rhs.
     * <p>Requires: lhs and rhs are instances of AbstractExpr, op is a mathematical operator
     *
     * @param op mathematical operator
     * @param lhs first mathematical expression
     * @param rhs second mathematical expression
     */
    public BinaryNumeric(TokenType op, AbstractExpr lhs, AbstractExpr rhs) {
        if (!(op.category().equals(TokenCategory.ADDOP) || op.category().equals(TokenCategory.MULOP))) {
            throw new IllegalArgumentException();
        }
        this.token = op;
        lhs.setParent(this);
        rhs.setParent(this);
        this.children.add(lhs);
        this.children.add(rhs);
    }

    public BinaryNumeric() {}

    private int left(){
       return ((AbstractExpr)children.get(0)).getValue();
    }

    private int right(){
        return ((AbstractExpr)children.get(1)).getValue();
    }


    /** Returns the value of current node */
    @Override
    public int getValue() {

        switch (token) {
            case TokenType.PLUS:
                return left() + right();

            case TokenType.MINUS:
                return left() - right();

            case TokenType.MUL:
                return left() * right();

            case TokenType.DIV:
                if (right() == 0) return 0;
                else return Math.floorDiv(left(), right());

            case TokenType.MOD:
                if (right() == 0) return 0;
                else return Math.floorMod(left(), right());
        }
        throw new IllegalArgumentException("The BinaryNumeric has invalid token.");
    }

    /**
     * Prints a pretty BinaryNumeric Node, explicitly adds a space between mod to prevent mixups
     * @param sb The {@code StringBuilder} to which the program will be appended
     * @return sb of the node
     */
    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        printChild(false, sb);
        switch (token) {
            case TokenType.PLUS:
                sb.append("+");
                break;
            case TokenType.MINUS:
                sb.append("-");
                break;
            case TokenType.MUL:
                sb.append("*");
                break;
            case TokenType.DIV:
                sb.append("/");
                break;
            case TokenType.MOD:
                sb.append(" mod ");
                break;
        }
        printChild(true, sb);
        return sb;
    }

    /**
     * Calls pretty print on the given node, adding parentheses if needed.
     * @param isRight true if printing right child, else prints left child.
     * @param sb the StringBuilder to which the expression will be appended.
     * @return the StringBuilder to which this expression was appended.
     */
    private StringBuilder printChild (boolean isRight, StringBuilder sb) {
        boolean paren = needParentheses(isRight);
        Node node = (isRight ? children.get(1) : children.get(0));
        if (isRight&& getToken().equals(TokenType.MINUS)){
            if (((AbstractNode) children.get(1)).getToken().equals(TokenType.NUM)) {
                if (((Numeric) children.get(1)).getValue()<0) sb.append(" ");
            } else if (children.get(1) instanceof UnaryNumeric) {
                sb.append(" ");
            }
        }
        if (paren) {
            sb.append("(");
        }
        node.prettyPrint(sb);
        if (paren) {
            sb.append(")");
        }
        return sb;
    }

    /**
     * Returns true if the specified child needs parentheses around it, otherwise false.
     * @param checkingRight whether to check right child or left
     * @return true if the specified child needs parentheses around it, otherwise false.
     */
    private boolean needParentheses(boolean checkingRight) {
        if (checkingRight && (children.get(1) instanceof BinaryNumeric)) {
            return true;
        }
        if (checkingRight && !(children.get(1) instanceof BinaryNumeric) ||
                !checkingRight && !(children.get(0) instanceof BinaryNumeric)) {
            return false;
        }
        BinaryNumeric node = (BinaryNumeric)(checkingRight ? children.get(1) : children.get(0));
        if (checkingRight) {
            if (node.token.equals(TokenType.DIV) || node.token.equals(TokenType.MOD)) {
                return true;
            }
        }
        if (!node.token.category().equals(TokenCategory.MULOP)) {
            if (checkingRight && token.equals(TokenType.MINUS)) {
                return true;
            }
            return token.category().equals(TokenCategory.MULOP);
        }
        return false;
    }

    /**
     * Returns whether the AST under this node is well-formed. For use in assertions.
     */
    @Override
    public boolean classInv() {
        if (children.size() == 2 && (children.get(0) instanceof AbstractExpr) && (children.get(1) instanceof AbstractExpr)) {
            return children.get(0).classInv() && children.get(1).classInv();
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof BinaryNumeric)) {
            return false;
        }
        List<Node> list = ((BinaryNumeric)o).getChildren();
        return ((BinaryNumeric)o).token.equals(token) && children.getFirst().equals(list.getFirst()) && children.get(1).equals(list.get(1));
    }
}
