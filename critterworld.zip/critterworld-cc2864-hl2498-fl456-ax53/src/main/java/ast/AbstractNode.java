package ast;

import java.util.ArrayList;
import java.util.List;
import cms.util.maybe.Maybe;
import parse.TokenType;

/**
 * Abstract class representing a node in a critter program AST.
 */
public abstract class AbstractNode implements Node {
    protected TokenType token;
    protected Node parent;
    protected List<Node> children = new ArrayList<Node>();
    protected static int curindex;

    int id;
    protected static int counter;

    public AbstractNode(){
    }

    protected ProgramImpl findRootNode(){
        AbstractNode current = this;
        while(current != null){
            if (current instanceof ProgramImpl) return (ProgramImpl)current;
            else current = (AbstractNode) current.parent;
        }
        return null;
    }

    @Override
    public String toString() {
        return prettyPrint(new StringBuilder()).toString();
    }

    @Override
    public int size(){
        int size = 1;
        for (Node child : children) {
            size += child.size();
        }
        return size;
    }

    @Override
    public Node nodeAt(int index) {
        curindex = 0;
        return nodeAtSearch(index);
    }

    /**
     * Recursively search for the node at the given index.
     * @param goal the index of the target node.
     * @return the node corresponding to goal.
     */
    protected Node nodeAtSearch(int goal) {
        if (curindex++ == goal) {
            return this;
        }
        List<Node> list = getChildren();
        for (Node node : list) {
            Node ret = ((AbstractNode) node).nodeAtSearch(goal);
            if (ret != null) {
                return ret;
            }
        }
        return null;
    }

    /**
     * Sets the unique IDs of every node in the critter program tree.
     */
    public void setIds() {
        counter = 0;
        setIdRecursive();
    }

    protected void setIdRecursive() {
        id = counter++;
        List<Node> children = getChildren();
        for (Node node : children) {
            ((AbstractNode)node).setIdRecursive();
        }
    }

    @Override
    public abstract StringBuilder prettyPrint(StringBuilder sb);

    @Override
    public Node clone(){
        try {
            AbstractNode cloned = this.getClass().getDeclaredConstructor().newInstance();
            List<Node> clonedChildren = new ArrayList<>();
            for (Node child : children) {
                Node clonedChild = child.clone();
                clonedChild.setParent(cloned);
                clonedChildren.add(clonedChild);
            }
            cloned.children = clonedChildren;
            if (token != null) cloned.token = this.token;
            return cloned;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Node> getChildren(){
        return children;
    }


    /**
     * Returns the parent of this {@code Node}, or {@Maybe.none} if this {@code Node} is the root.
     *
     * @return the parent of this {@code Node}, or {@Maybe.none} if this {@code Node} is the root.
     *
     * This method does not need to be implemented and may be removed from the interface.
     */
    public Maybe<Node> getParent() {
        if (parent != null) {
            return Maybe.some(parent);
        }
        return Maybe.none();
    }

    /**
     p.getChildren().add(p);
     }
     * You can remove this method if you don't like it.
     * Sets the parent of this {@code Node}.
     *
     * @param p the node to set as this {@code Node}'s parent.
     */
    public void setParent(Node p) {
        parent = p;
    }

    /**
     * Returns the tokenType of this node
     * @return tokenType stored at the node
     */

    public TokenType getToken(){
        return token;
    }

    /**
     * Prints out an interpretable representation of the node
     * @return the node's class name and token type
     */

    @Override
    public String printNode(){
        String tokenStr = token != null ? token.toString() : "null";
        if (parent != null){
            return getClass().getSimpleName() + ": " + tokenStr ;
        } else {
            return getClass().getSimpleName() + ": " + tokenStr;
        }
    }

    /**
     * Returns the parent node object of the current node without enforcing any maybe checks
     * @return node parent if exists, null otherwise
     */
    public Node getParentNode(){
        if (parent == null){
            throw new IllegalArgumentException("cannot return the parent of a: " + token + "node");
        }
        return parent;
    }

}
