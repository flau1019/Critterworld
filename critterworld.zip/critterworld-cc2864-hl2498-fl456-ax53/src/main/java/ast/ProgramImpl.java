package ast;

import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import parse.TokenType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;


/** A data structure representing a critter program. */
public class ProgramImpl extends AbstractNode implements Program {
    public HashMap<Class<? extends Node>, ArrayList<AbstractNode>> allNodes;

    /**
     * Creates an AST representing a critter program with a set of rules.
     * @param rules set of rules for the program.
     */
    public ProgramImpl(ArrayList<Rule> rules) {
        this.token = TokenType.PROGRAM;
        this.children = new ArrayList<>();
        for (Rule rule : rules) {
            rule.setParent(this);
            children.add(rule);
        }
        this.allNodes = new HashMap<>(5);
    }

    /**
     * Applies a randomly chosen mutation on a randomly selected node the in AST
     * @Effect mutates the program if possible, otherwise does nothing to the AST
     * @return the program with the mutations applied
     */
    @Override
    public Program mutate() {
        // while no mutation has succeeded yet, choose a random mutation
        // and random node, and try to apply the mutation to the node
        Random rand = new Random();
        while (true) {
            Mutation m = getRandMutation(rand);
            try {
                return mutate(rand.nextInt(size()), m).get();
            } catch (NoMaybeValue ignored) {
            }
        }
    }

    /**
     * Return a randomly selected mutation out of the 6 possible mutations.
     * @param rand random number generator to get the next mutation.
     * @return a randomly selected mutation out of the 6 possible mutations.
     */
    private static Mutation getRandMutation(Random rand) {
        int mutation = rand.nextInt(6);
        return switch (mutation) {
            case 1 -> MutationFactory.getDuplicate();
            case 2 -> MutationFactory.getInsert();
            case 3 -> MutationFactory.getRemove();
            case 4 -> MutationFactory.getReplace();
            case 5 -> MutationFactory.getSwap();
            default -> MutationFactory.getTransform();
        };
    }

    @Override
    public Maybe<Program> mutate(int index, Mutation m) {
        if (index >= this.size()) {
            throw new IllegalArgumentException("Index " + index + " is out of bounds for ProgramImpl of size " + size());
        }
        return m.apply(this, nodeAt(index));
    }

    /**
     * Finds randomly selected Node of the right type in the AST to some NodeCategory type
     * @param type the category to chose from
     * @return randomly selected node from the AST within the same nodecategory as param
     */
    @Override
    public Maybe<Node> findNodeOfType(NodeCategory type) {
        ArrayList<AbstractNode> allNodes = null;
        try {
            if (type.equals(NodeCategory.PROGRAM)) {
                allNodes = findListOfType(ProgramImpl.class).get();
            } else if (type.equals(NodeCategory.RULE)) {
                allNodes = findListOfType(Rule.class).get();
            } else if (type.equals(NodeCategory.COMMAND)) {
                allNodes = findListOfType(BinaryUpdate.class).get();
                allNodes.addAll(findListOfType(Action.class).get());
            } else if (type.equals(NodeCategory.UPDATE)) {
                allNodes = findListOfType(BinaryUpdate.class).get();
            } else if (type.equals(NodeCategory.ACTION)) {
                allNodes = findListOfType(Action.class).get();
            } else if (type.equals(NodeCategory.CONDITION)) {
                allNodes = findListOfType(BinaryOp.class).get();
                allNodes.addAll(findListOfType(BinaryRel.class).get());
            } else if (type.equals(NodeCategory.EXPRESSION)) {
                allNodes = findListOfType(Numeric.class).get();
                allNodes.addAll(findListOfType(MemGet.class).get());
                allNodes.addAll(findListOfType(Sensor.class).get());
                allNodes.addAll(findListOfType(BinaryNumeric.class).get());
            }
        } catch (NoMaybeValue ignored) {}
        if (allNodes == null) {
            return Maybe.none();
        }
        return Maybe.some(allNodes.get((new Random()).nextInt(allNodes.size())));
    }

    /**
     * Returns an arraylist of all the nodes that are objects of the specified class, or Maybe.none() if no nodes found.
     * @param type the class type.
     * @return an arraylist of all the nodes that are objects of the specified class, or Maybe.none() if no nodes found.
     */
    private Maybe<ArrayList<AbstractNode>> findListOfType(Class<? extends Node> type) {
        if (!allNodes.containsKey(type)) {
            return Maybe.none();
        }
        return Maybe.some(allNodes.get(type));
    }

    /**
     * Getter of children
     * @return
     */

    @Override
    public List<Node> getChildren(){
        return children;
    }

    /**
     * The number of nodes in the AST rooted at this node, including this node
     *
     * @return The size of the AST rooted at this node
     */
    @Override
    public int size() {
        int total = 1; // +1 for this node
        for (Node child : children) {
            total += child.size();
        }
        return total;
    }

    /**
     * Prints a pretty Program
     * @param sb The {@code StringBuilder} to which the program will be appended
     * @return a well-formatted, pretty printed AST
     */

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        for (int i = 0; i < children.size(); i++) {
            Node rule = children.get(i);
            rule.prettyPrint(sb);
            if (i < children.size() - 1) {
                sb.append(";\n");
            } else{
                sb.append(";");
            }
        }
        return sb;
    }


    /**
     * Deep clones a node
     * @return deep-cloned node
     */
    @Override
    public Node clone() {
        ArrayList<Rule> rules2 = new ArrayList<>();
        for (Node rule : children) {
            rules2.add((Rule)rule.clone());
        }
        return new ProgramImpl(rules2);
    }

    @Override
    public NodeCategory getCategory() {
        return NodeCategory.PROGRAM;
    }

    /**
     * Checks that the program contains at least one rule (child), thus the class inv is true
     * @return True if the class INV is maintained, false otherwise
     */
    @Override
    public boolean classInv() {
        for (Node rule : children) {
            if (!rule.classInv()) {
                return false;
            }
        }
        return !children.isEmpty();
    }

    /**
     * Adds a node to the HashMap recording all the nodes in this program.
     * @param node node to add to the map.
     */
    public void addNode(AbstractNode node){
        if (!allNodes.containsKey(node.getClass())){
            ArrayList<AbstractNode> nodes = new ArrayList<>();
            nodes.add(node);
            allNodes.put(node.getClass(), nodes);
        }
        else {
            allNodes.get(node.getClass()).add(node);
        }
    }

    /**
     * Removes the node from the HashMap recording all the nodes in this program.
     * If node is not present, does nothing.
     * <p>Requires: there is at most 1 instance of the node in the HashMap.
     * @param node the node to remove.
     */
    public void removeNode(AbstractNode node) {
        if (allNodes.containsKey(node.getClass())) {
            ArrayList<AbstractNode> nodes = allNodes.get(node.getClass());
            for (int i = 0; i < nodes.size(); i++) {
                if (nodes.get(i) == node) {
                    // check if both point to the same object
                    // NOT whether the contents are equal
                    nodes.remove(i);
                    allNodes.put(node.getClass(), nodes);
                    return; // assumes only one reference to node in the entire list
                }
            }
        }
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ProgramImpl r)) {
            return false;
        }
        List<Node> rules = r.getChildren();
        if (rules.size() != children.size()) {
            return false;
        }
        for (int i = 0; i < rules.size(); i++) {
            if (!(rules.get(i)).equals(children.get(i))) {
                return false;
            }
        }
        return true;
    }
}
