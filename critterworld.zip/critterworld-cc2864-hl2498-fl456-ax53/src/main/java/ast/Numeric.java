package ast;

import parse.TokenType;

import java.util.ArrayList;

/**
 * A single positive integer.
 */
public class Numeric extends AbstractExpr {
    int value;

    /**
     * Creates a node representing the given value.
     * @param value value for the AST node.
     */
    public Numeric(int value) {
        token = TokenType.NUM;
        this.value = value;
        children = new ArrayList<>(); // list of children should be empty
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        sb.append(value);
        return sb;
    }

    @Override
    public Node clone() {
        return new Numeric(value);
    }

    /**
     * Returns value stored in this node.
     * @return value stored in this node.
     */
    public int getValue() { return value; }

    /**
     *
     * @return whether there's no children and value stored in this node is positive
     */
    @Override
    public boolean classInv() {
        return children.isEmpty() && value >= 0;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Numeric n)) {
            return false;
        }
        return value == n.value;
    }

    @Override
    public String printNode(){
        return "<num>"+value;
    }
}
