package ast;

import parse.TokenType;

/**
 * Represents a negation of a mathematical expression.
 */
public class UnaryNumeric extends AbstractExpr {
    /**
     * Creates a node representing -(expr).
     * @param value mathematical expression to negate.
     */
    public UnaryNumeric(AbstractExpr value) {
        token = TokenType.MINUS;
        value.setParent(this);
        children.add(value);
    }

    @Override
    public int getValue() {
        return -(((AbstractExpr)children.getFirst()).getValue());
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        AbstractExpr child = (AbstractExpr) children.getFirst();
        boolean needParen = !(child instanceof Numeric || child instanceof AbstractRetrieve);
        sb.append("-");
        if (needParen) {
            sb.append("(");
        }
        children.getFirst().prettyPrint(sb);
        if (needParen) {
            sb.append(")");
        }
        return sb;
    }

    @Override
    public boolean classInv() {
        if (children.size() == 1 && children.getFirst() instanceof AbstractExpr) {
            return children.getFirst().classInv();
        }
        return false;
    }

    @Override
    public Node clone() {
        return new UnaryNumeric((AbstractExpr) children.getFirst().clone());
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof UnaryNumeric node)) {
            return false;
        }
        return children.getFirst().equals(node.children.getFirst());
    }
}
