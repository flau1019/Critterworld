package ast.Mutate;

import ast.*;
import ast.ProgramImpl;
import ast.Program;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import parse.TokenCategory;
import parse.TokenType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents an insert mutation.
 * Inserts a new node as the parent of the specified node, making the original node a child
 * and adjusting other children as needed based on the newly inserted node's type.
 */
public class Insert extends AbstractMutate {
    public Insert() {
        mutation = MutationType.INSERT;
    }

    /**
     * Applies an insertion mutation to the given {@code Node} within this {@code Program}, inserting a new node as the parent of the current node.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node inserted or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        if (!canApply(this, node)) {
            return Maybe.none();
        } else {
            Random random = new Random();
            List<Class<? extends Node>> parents = candidateParents(node);
            Class<? extends Node> parentClass = parents.get(random.nextInt(parents.size()));
            Node oldParent = node.getParentNode();
            AbstractNode parent = null;
            if (node instanceof AbstractExpr abstractExpr) {
                if (Sensor.class.isAssignableFrom(parentClass)) {
                    parent = new Sensor(getRandToken(TokenCategory.SENSOR, TokenType.SMELL), abstractExpr);

                } else if (MemGet.class.isAssignableFrom(parentClass)) {
                    parent = new MemGet(abstractExpr);

                } else if (BinaryNumeric.class.isAssignableFrom(parentClass)) {
                    try {
                        Node rightChild = chooseFromAbstractExpr(program, null).get();
                        rightChild =rightChild.clone();
                        parent = new BinaryNumeric(getRandToken(TokenCategory.ADDOP, TokenType.SERVE), abstractExpr, (AbstractExpr) rightChild);

                    } catch (NoMaybeValue e) {
                        return Maybe.none();
                    }
                } else if (BinaryRel.class.isAssignableFrom(parentClass)) {
                    try {
                        Node rightChild = chooseFromAbstractExpr(program, null).get().clone();
                        parent = new BinaryRel(getRandToken(TokenCategory.RELOP, TokenType.SMELL), abstractExpr, (AbstractExpr) rightChild);
                        System.out.println(parent.printNode());

                    } catch (NoMaybeValue e) {
                        return Maybe.none();
                    }
                }
            } else if (node instanceof AbstractBinaryBool) {
                if (node instanceof BinaryOp){
                    try {
                        Node rightChild = chooseFromAbstractBool(program, null).get().clone();
                        parent = new BinaryOp(getRandToken(TokenCategory.BINOP, TokenType.SMELL), (AbstractBinaryBool) node, (AbstractBinaryBool) rightChild);

                    } catch (NoMaybeValue e) {
                        return Maybe.none();
                    }
                } else{
                    try {
                        Node rightChild = chooseFromBinaryRel(program, null).get().clone();
                        parent = new BinaryOp(getRandToken(TokenCategory.BINOP, TokenType.SMELL), (AbstractBinaryBool) node, (AbstractBinaryBool) rightChild);

                    } catch (NoMaybeValue e) {
                        return Maybe.none();
                    }
                }

            }
            if (parent != null) {
                parent.setParent(oldParent);
                ((ProgramImpl) program).addNode(parent);
                oldParent.getChildren().add(oldParent.getChildren().indexOf(node), parent);
                boolean removed = oldParent.getChildren().remove(node);
                if (!removed) {
                    return Maybe.none();
                }
                return Maybe.some(program);
            }
        }
        return Maybe.none();

    }


    private List<Class<? extends Node>> candidateParents(Node node) {
        List<Class<? extends Node>> p = new ArrayList<>();

        if (node instanceof MemGet && (node.getParentNode() instanceof BinaryUpdate)) {
            p.add(MemGet.class);
        }
        else if (node instanceof AbstractExpr) {
            if (node.getParentNode() instanceof BinaryOp){
                p.add(BinaryRel.class);
            }
            p.add(BinaryNumeric.class);
            p.add(MemGet.class);
            p.add(Sensor.class);

        } else if (node instanceof BinaryOp || node instanceof BinaryRel) {
            p.add(BinaryOp.class);
        }
        return p;


    }

}

