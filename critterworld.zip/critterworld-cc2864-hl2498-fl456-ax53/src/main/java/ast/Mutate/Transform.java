package ast.Mutate;

import ast.*;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import parse.TokenCategory;
import parse.TokenType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents a transform mutation.
 * The node is replaced with a random, newly created node of the same kind (for example,
 * replacing attack with eat, or + with *), but its children remain the same.
 *
 * Requires: the children of the original node must remain unchanged and attached to the transformed node.
 */
public class Transform extends AbstractMutate{
    public Transform() {
        mutation = MutationType.TRANSFORM;
    }

    /**
     * Applies a transformation mutation to the given {@code Node} within this {@code Program}, replacing the node with a newly created node of the same type while keeping its children.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node transformed or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        if (!canApply(this, node)) {
            return Maybe.none();
        }
        AbstractNode tnode = null;
        if (node instanceof Numeric num) {
            int n;
            do {
                n = Integer.MAX_VALUE/(new Random().nextInt());
            } while (n == num.getValue());
            tnode = new Numeric(n);
        } else {
            TokenType t = getRandToken(node.getToken().category(), node.getToken());
            if (node instanceof Action) {
                tnode = new Action(t);
            } else if (node instanceof AbstractBinaryBool || node instanceof BinaryNumeric) {
                List<Node> children = node.getChildren();
                if (node instanceof BinaryOp) {
                    tnode = new BinaryOp(t, (AbstractBinaryBool) children.get(0), (AbstractBinaryBool) children.get(1));
                } else if (node instanceof BinaryRel) {
                    tnode = new BinaryRel(t, (AbstractExpr) children.get(0), (AbstractExpr) children.get(1));
                } else {
                    tnode = new BinaryNumeric(t, (AbstractExpr) children.get(0), (AbstractExpr) children.get(1));
                }
            } else if (node instanceof Sensor s) {
                tnode = new Sensor(t, (AbstractExpr) s.getChildren().getFirst());
            } else {
                return Maybe.none();
            }
        }
        try {
            tnode.setParent((node).getParent().get());
            replace(program, node, tnode);
            return Maybe.some(program);
        } catch (NoMaybeValue e) {
            return Maybe.none();
        }
    }

}
