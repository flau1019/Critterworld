package ast.Mutate;

import ast.*;
import cms.util.maybe.Maybe;

import java.util.Collections;
import java.util.List;
import java.util.Random;
/**
 * Represents a swap mutation.
 * The order of two children of the node is switched.
 * For example, this allows swapping the positions of two rules,
 * or changing a − b to b − a.
 */
public class Swap extends AbstractMutate{
    public Swap() {
        mutation = MutationType.SWAP;
    }

    /**
     * Applies a swap mutation to the given {@code Node} within this {@code Program}, switching the order of two children of the node.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node's children swapped or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        Random rand = new Random();
        DistinctRand distinctRand = new DistinctRand(rand);
        if (!canApply(this, node)){
            return Maybe.none();
        }else{
            if (node instanceof Rule rule){
                int [] swaps = distinctRand.genRandDist(1, rule.getChildren().size());
                swap(rule, swaps[0], swaps[1]);
            } else {
                int [] swaps = distinctRand.genRandDist(0, node.getChildren().size());
                swap(node, swaps[0], swaps [1]);
            }
            return Maybe.some(program);
        }
    }

    private void swap(Node parent, int idx, int idx1) {
        Node temp = parent.getChildren().get(idx);
        parent.getChildren().set(idx, parent.getChildren().get(idx1));
        parent.getChildren().set(idx1, temp);
    }
}
