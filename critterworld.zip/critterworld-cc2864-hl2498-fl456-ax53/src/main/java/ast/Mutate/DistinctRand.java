package ast.Mutate;
import java.util.Random;

/**
 * Generates distinct, random numbers from the same java.util.random instance (seed)
 */
public class DistinctRand {
    Random rand;

    public DistinctRand (Random random){
        rand=random;
    }

    /**
     * Generates two random, uniformly distributed distinct numbers within a given start and ending range
     * @param start lower random bound
     * @param end upper, non-inclusive, random bound
     * @return an int array with two elements containing teh randomly generated distinct values
     */
    public int[] genRandDist(int start, int end){
        int[] rands = new int[2];
        rands[0] = rand.nextInt(start, end);
        rands[1] = rand.nextInt(start, end-1);
        if (rands[1]>=rands[0]){
            rands[1]++;
        }
        return rands;
    }
}
