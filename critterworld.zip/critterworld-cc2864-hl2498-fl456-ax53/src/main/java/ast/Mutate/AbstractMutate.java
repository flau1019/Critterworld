package ast.Mutate;

import ast.*;
import ast.Program;
import ast.Rule;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import parse.TokenCategory;
import parse.TokenType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class AbstractMutate implements Mutation {

    /**
     * enum for tracking what the class type of a given mutation is during runtime
     */
    protected enum MutationType {
        DUPLICATE,
        INSERT,
        REMOVE,
        REPLACE,
        SWAP,
        TRANSFORM
    }

    protected MutationType mutation;

    /**
     * Compares the type of this mutation to {@code m}
     *
     * @param m The mutation to compare with
     * @return Whether this mutation is the same type as {@code m}
     */
    @Override
    public boolean equals(Mutation m) {
        return this.mutation.equals(((AbstractMutate)m).mutation);
    }
    /**
     * Applies this mutation to the given {@code Node} within this {@code Program}
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a mutated program or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public abstract Maybe<Program> apply(Program program, Node node);
    /**
     * Returns true if and only if this type of mutation can be applied to the given node.
     * @param n the node to mutate
     * @return whether this mutation can be applied to {@code n}
     */
    @Override
    public boolean canApply(Mutation m, Node n) {
        if (m instanceof Swap){
            return canApplySwap(n);
        } else if (m instanceof Transform) {
            return canApplyTransform(n);
        } else if (m instanceof Replace) {
            return canApplyReplace(n);
        } else if (m instanceof Duplicate) {
            return canApplyDuplicate(n);
        } else if (m instanceof Remove){
            return canApplyRemove(n);
        } else if (m instanceof Insert){
            return canApplyInsert(n);
        }
        return false;
    }

    /**
     * Returns true if and only if insert can be applied to {@code n}
     * @param n the node to mutate
     * @return whether insert can be applied to {@code n}
     */
    private boolean canApplyInsert(Node n){
        return !(n instanceof ProgramImpl || n instanceof Rule || n instanceof Action || n instanceof BinaryUpdate);
    }
    /**
     * Returns true if and only if replace can be applied to {@code n}
     * @param n the node to mutate
     * @return whether replace can be applied to {@code n}
     */
    private boolean canApplyReplace(Node n){
        return !(n instanceof ProgramImpl);
    }
    /**
     * Returns true if and only if swap can be applied to {@code n}
     * @param n the node to mutate
     * @return whether swap can be applied to {@code n}
     */
    private boolean canApplySwap(Node n){
        if (n instanceof Rule rule){
            return rule.getCommands().size()>1;
        }
        return !(n instanceof BinaryUpdate) && n.getChildren().size() > 1;
    }

    /**
     * Returns true if and only if trasnform can be applied to {@code n}
     * @param n the node to mutate
     * @return whether transform can be applied to {@code n}
     */
    private boolean canApplyTransform(Node n){
        if (n instanceof Rule || n instanceof ProgramImpl || n instanceof BinaryUpdate) {
            return false;
        } else if (n instanceof Sensor s) {
            return !s.getToken().equals(TokenType.SMELL);
        } else if (n instanceof Action a) {
            return !a.getToken().equals(TokenType.SERVE);
        }
        return true;
    }
    /**
     * Returns true if and only if duplicate can be applied to {@code n}
     * @param n the node to mutate
     * @return whether duplicate can be applied to {@code n}
     */
    private boolean canApplyDuplicate(Node n){
        return (n instanceof Rule || n instanceof ProgramImpl);
    }

    /**
     * Returns true if and only if remove can be applied to {@code n}
     *
     * @param n the node to mutate
     * @return whether remove can be applied to {@code n}
     */
    private boolean canApplyRemove(Node n)  {
        if (n instanceof ProgramImpl || n instanceof Numeric) {
            return false;
        } else if (n instanceof Rule rule) {
            Node prog = rule.getParentNode();
            return (prog.getChildren().size()>1);
        } else if (n instanceof Action a) {
            Node rule = a.getParentNode();
            return (rule.getChildren().size()>2); // at least 1 condition and 1 command
        } else if (n instanceof BinaryUpdate b) {
            Node rule = b.getParentNode();
            return (rule.getChildren().size()>2); // at least 1 condition and 1 command
        } else if (n instanceof MemGet m) {
            Node parent = m.getParentNode();
            return !((parent instanceof BinaryUpdate) && parent.getChildren().getFirst() == n);
        } else if (n instanceof AbstractRetrieve r) {
            return !(r.getToken().equals(TokenType.SMELL));
        } else if (n instanceof BinaryRel binaryRel){
            if (!(binaryRel.getChildren().getFirst() instanceof BinaryRel || binaryRel.getChildren().get(1) instanceof BinaryRel)){
                return false;
            }
        } else if (n instanceof BinaryOp binaryOp){
            if (!(binaryOp.getChildren().getFirst() instanceof BinaryOp || binaryOp.getChildren().get(1) instanceof BinaryOp)){
                return false;
            }
        }
        return true;
    }

    /**
     * Replace the node "old" and its descendants are replaced by the node "node".
     * @param p program containing the old node.
     * @param old the original node to replace.
     * @param node the new node to add to the program.
     * @return the program if replace was successful, otherwise Maybe.none()
     */
    protected Maybe<Program> replace(Program p, Node old, Node node) {
        try {
            Node parent = ((AbstractNode)old).getParent().get();
            List<Node> children = parent.getChildren();
            for (int i = 0; i < children.size(); i++) {
                if (children.get(i) == old) {
                    children.set(i, node);
                }
            }
            ((ProgramImpl)p).addNode((AbstractNode)node);
            ((ProgramImpl)p).removeNode((AbstractNode)old);
            return Maybe.some(p);
        } catch (NoMaybeValue ignored) {
            return Maybe.none();
        }
    }

    /**
     * Returns a random node taken from the critter program p of class type c and
     * that is not equal to the node notEquals (this is to avoid randomly choosing
     * the node that we are trying to mutate).
     * <p>Requires: notEquals is not the only node in p with class type c.
     * @param prog a critter program AST.
     * @param c an AST node class.
     * @param notEquals the node to avoid.
     * @return a random node taken from the critter program p of class type c, or Maybe.none() if there
     * is no way to choose a different random node.
     */
    protected Maybe<Node> chooseFromClass(Program prog, Class<? extends Node> c, Node notEquals) {
        try {
            List<AbstractNode> allNodes = chooseAllFromClass(prog, c, notEquals).get();

            if (allNodes.isEmpty()) {
                return Maybe.none();
            }
            int n = allNodes.size();
            Random random = new Random();
            return Maybe.some(allNodes.get(random.nextInt(n)));
        } catch (NoMaybeValue e) {
            return Maybe.none();
        }
    }

    /**
     * Returns all nodes from prog that are of the class type c and are not
     * equal to the node "notEquals" (this is to avoid randomly choosing
     * the node that we are trying to mutate).
     * @param prog a critter program AST.
     * @param c an AST node class.
     * @param notEquals the node to avoid.
     * @return all nodes from prog that are of the class type c and are not
     * equal to the node "notEquals"
     */
    protected Maybe<ArrayList<AbstractNode>> chooseAllFromClass(Program prog, Class<? extends Node> c, Node notEquals) {
        if (!(prog instanceof ProgramImpl p)) {
            return Maybe.none();
        }
        ArrayList<AbstractNode> allNodes = p.allNodes.get(c);
        if (allNodes == null) {
            return Maybe.none();
        }

        ArrayList<AbstractNode> filtered = new ArrayList<>();
        if (allNodes == null) return Maybe.none();
        for (AbstractNode n : allNodes) {
            if (n == notEquals) { continue; }
            filtered.add(n);
        }
        return Maybe.some(filtered);
    }


    /**
     * Returns a random token of type cat and not equal to the tokentype notEquals.
     * If the given cat is ADDOP or MULOP, the returned token can be of type ADDOP or MULOP.
     * @param cat a type of token.
     * @param notEquals the tokentype to avoid picking.
     * @return a random token of type cat and not equal to the tokentype notEquals.
     */
    protected TokenType getRandToken(TokenCategory cat, TokenType notEquals) {
        List<TokenType> candidates;
        if (cat.equals(TokenCategory.ADDOP) || cat.equals(TokenCategory.MULOP)) {
            candidates = getCandidates(TokenCategory.ADDOP, notEquals);
            candidates.addAll(getCandidates(TokenCategory.MULOP, notEquals));
        } else {
            candidates = getCandidates(cat, notEquals);
        }
        return candidates.get((new Random()).nextInt(candidates.size()));
    }

    /**
     * Returns a list of all tokens of type cat and are not equal to the tokentype notEquals.
     * @param cat a type of token.
     * @param notEquals the tokentype to avoid picking.
     * @return a list of all tokens of type cat and are not equal to the tokentype notEquals.
     */
    protected List<TokenType> getCandidates(TokenCategory cat, TokenType notEquals) {
        List<TokenType> candidates = new ArrayList<>();
        for (TokenType t : TokenType.values()) {
            if (t.category().equals(cat) && !t.equals(notEquals)) {
                if ((cat.equals(TokenCategory.SENSOR) && t.equals(TokenType.SMELL)) ||
                        (cat.equals(TokenCategory.ACTION) && t.equals(TokenType.SERVE))) {
                    continue;
                }
                candidates.add(t);
            }
        }
        return candidates;
    }


    /**
     * Returns a random node in the program that is of type AbstractBinaryBool and not
     * equal to node.
     * @param program a critter program AST
     * @param node the node to avoid choosing
     * @return random node in the program that is of type AbstractBinaryBool and not
     * equal to node.
     */
    protected Maybe<Node> chooseFromAbstractBool(Program program, Node node) {
        try {
            List<AbstractNode> potential = chooseAllFromClass(program, BinaryOp.class, node).get();
            potential.addAll(chooseAllFromClass(program, BinaryRel.class, node).get());
            return Maybe.some(potential.get((new Random()).nextInt(potential.size())));
        } catch (NoMaybeValue ignored) {}
        return Maybe.none();
    }

    protected Maybe<Node> chooseFromBinaryRel(Program program, Node node) {
        try {
            List<AbstractNode> potential = chooseAllFromClass(program, BinaryRel.class, node).get();
            return Maybe.some(potential.get((new Random()).nextInt(potential.size())));
        } catch (NoMaybeValue ignored) {}
        return Maybe.none();
    }


    /**
     * Returns a random node in the program that is of type AbstractExpr and not
     * equal to node.
     * @param program a critter program AST
     * @param node the node to avoid choosing
     * @return random node in the program that is of type AbstractExpr and not
     * equal to node.
     */
    protected Maybe<Node> chooseFromAbstractExpr(Program program, Node node) {
        List<AbstractNode> potential = new ArrayList<AbstractNode>();
        Class<? extends AbstractExpr>[] candidates = new Class[]{Numeric.class, Sensor.class, MemGet.class, BinaryNumeric.class};
        for (Class c : candidates) {
            try {
                potential.addAll((ArrayList)chooseAllFromClass(program, c, node).get());
            } catch (NoMaybeValue ignored) {}
        }
        return (!potential.isEmpty() ? Maybe.some(potential.get((new Random()).nextInt(potential.size()))) : Maybe.none());
    }

    /**
     * Returns a random node in the program that is of type AbstractExpr and not
     * equal to node.
     * @param program a critter program AST
     * @param node the node to avoid choosing
     * @return random node in the program that is of type AbstractExpr and not
     * equal to node.
     */
    protected Maybe<Node> chooseFromCommand(Program program, Node node) {
        try {
            List<AbstractNode> potential = chooseAllFromClass(program, BinaryUpdate.class, node).get();
            potential.addAll(chooseAllFromClass(program, Action.class, node).get());
            return Maybe.some(potential.get((new Random()).nextInt(potential.size())));
        } catch (NoMaybeValue ignored) {}
        return Maybe.none();
    }
}
