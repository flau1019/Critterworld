package ast.Mutate;

import ast.*;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;

/**
 * Represents a replace mutation.
 * Replaces the specified node and its descendants with a randomly selected subtree of the same type,
 * chosen from within the current AST, and deep-copied to fit into the program.
 *
 * Requires: the AST structure must remain valid after the replacement, with no orphaned or cyclic nodes.
 */


public class Replace extends AbstractMutate{
    public Replace() {
        mutation = MutationType.REPLACE;
    }

    /**
     * Applies a replacement mutation to the given {@code Node} within this {@code Program}, substituting the node with a randomly selected subtree of the same type.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node replaced or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        if (!canApply(this, node)) {
            return Maybe.none();
        }
        try {
            Node rep = null;
            if (node instanceof AbstractBinaryBool) {
                rep = chooseFromAbstractBool(program, node).get();
            } else if (node instanceof AbstractExpr) {
                if (node instanceof MemGet && node.getParentNode() instanceof BinaryUpdate && node.getParentNode().getChildren().getFirst() == node) {
                    rep = chooseFromClass(program, MemGet.class, node).get();
                } else {
                    rep = chooseFromAbstractExpr(program, node).get();
                }
            } else if (node instanceof BinaryUpdate) {
                if (((Rule)node.getParentNode()).hasAction()) {
                    rep = chooseFromClass(program, BinaryUpdate.class, node).get();
                } else {
                    rep = chooseFromCommand(program, node).get();
                }
            } else if (node instanceof Action) {
                rep = chooseFromCommand(program, node).get();
            } else if (node instanceof Rule) {
                if (program.getChildren().size()<=1){
                    return Maybe.none();
                }
                rep = chooseFromClass(program, Rule.class, node).get();
            }
            Node repclone = rep.clone();
            repclone.setParent(node.getParentNode());
            replace(program, node, repclone);
            return Maybe.some(program);
        } catch (NoMaybeValue ignored) {}
        return Maybe.none();
    }
}
