package ast.Mutate;

import ast.*;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;

import java.util.List;
import java.util.Random;

/**
 * Represents a duplicate mutation.
 * Duplicates the specified node or subtree, appending the duplicate as a new child of the same type,
 * which extends structures such as program rules or command sequences.
 *
 * Requires: node to be duplicated must support multiple children (>2)
 */

public class Duplicate extends AbstractMutate{
    public Duplicate() {
        mutation = MutationType.DUPLICATE;
    }

    /**
     * Applies a duplication mutation to the given {@code Node} within this {@code Program}, duplicating the node or subtree and appending it as a new child.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node duplicated or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        try {
            List<Node> children = node.getChildren();
            if (node instanceof ProgramImpl) {
                Node dup = chooseFromClass(program, Rule.class, null).get().clone();
                children.add(dup);
                ((ProgramImpl)program).addNode((AbstractNode)dup);
            } else if (node instanceof Rule) {
                boolean hasAction = false;
                for (Node command : children) {
                    if (command instanceof Action) {
                        hasAction = true;
                        break;
                    }
                }
                if (hasAction) {
                    Node dup = chooseFromClass(program, BinaryUpdate.class, null).get().clone();
                    children.add(dup);
                    ((ProgramImpl)program).addNode((AbstractNode)dup);
                } else {
                    List<AbstractNode> nodes = chooseAllFromClass(program, Action.class, null).get();
                    nodes.addAll(chooseAllFromClass(program, BinaryUpdate.class, null).get());
                    Node dup = nodes.get((new Random()).nextInt(nodes.size())).clone();
                    children.add(dup);
                    ((ProgramImpl)program).addNode((AbstractNode)dup);
                }
            }
        } catch (NoMaybeValue ignored) {}
        return Maybe.none();
    }
}
