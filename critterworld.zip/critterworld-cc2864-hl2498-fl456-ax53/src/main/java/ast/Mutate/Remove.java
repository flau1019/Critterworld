package ast.Mutate;

import ast.*;
import cms.util.maybe.Maybe;

import java.util.List;
import java.util.Random;
/**
 * Represents a remove mutation.
 * The specified node and all its descendants are removed from the program, with replacements if necessary
 * to maintain program structure (e.g., a binary operation node may be replaced by one of its children).
 *
 * Requires: node to remove is not the program root, and ensures the AST contains at least one rule at all times
 */

public class Remove extends AbstractMutate{
    public Remove() {
        mutation = MutationType.REMOVE;
    }

    /**
     * Applies a removal mutation to the given {@code Node} within this {@code Program}, removing the node and its descendants while maintaining program structure.
     *
     * @param program the program to be mutated.
     * @param node the specific node to perform mutation on.
     * @return a program with the node removed or {@code Maybe.none} if the mutation is unsuccessful.
     */
    @Override
    public Maybe<Program> apply(Program program, Node node) {
        if (!canApply(this, node)) {
            return Maybe.none();
        }
        ProgramImpl p = (ProgramImpl)program;
        if (node instanceof Rule rule) {
            List<Node> children = rule.getParentNode().getChildren();
            for (int i = 0; i < children.size(); i++) {
                if (children.get(i) == node) {
                    children.remove(i);
                    p.removeNode((AbstractNode) node);
                    return Maybe.some(program);
                }
            }
        } else if (node instanceof BinaryUpdate || node instanceof Action) {
            List<Node> children = node.getParentNode().getChildren();
            for (int i = 0; i < children.size(); i++) {
                if (children.get(i) == node) {
                    children.remove(i);
                    p.removeNode((AbstractNode) node);
                    return Maybe.some(program);
                }
            }
        } else if (node instanceof BinaryOp || node instanceof BinaryNumeric) {
            int i = (new Random()).nextInt(2);
            replace(p, node, node.getChildren().get(i));
        } else if (node instanceof AbstractRetrieve) {
            replace(p, node, node.getChildren().getFirst());
        } else if (node instanceof BinaryRel){
            int i = (new Random()).nextInt(2);
            replace (p, node, node.getChildren().get(i));
        }
        return Maybe.some(program);
    }
}
