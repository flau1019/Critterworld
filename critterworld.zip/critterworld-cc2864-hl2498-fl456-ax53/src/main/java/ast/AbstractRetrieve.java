package ast;

/**
 * Abstract class representing a memory index or sensor value.
 */
public abstract class AbstractRetrieve extends AbstractExpr{
}