package ast;

import model.Critter;
import parse.TokenType;

import java.util.ArrayList;

/**
 * A representation of a memory index in a critter program.
 */
public class MemGet extends AbstractRetrieve{

    /**
     * Constructs an AST node representing mem[index]
     * <p>Requires: index evaluates to a numerical value.
     * @param index index in the memory.
     */
    public MemGet(AbstractExpr index) {
        token = TokenType.MEM;
        children = new ArrayList<>();
        index.setParent(this);
        children.add(index);
    }

    public MemGet() {}

    /**
     * Returns whether the AST under this node is well-formed. For use in assertions.
     */
    @Override
    public boolean classInv() {
        if (children.size() != 1 || !(children.getFirst() instanceof AbstractExpr)) {
            return false;
        }
        return children.getFirst().classInv();
    }

    public int getValue(){
        Critter critter = InteractionHelper.getCritter(findRootNode());
        return critter.retrieve(TokenType.MEM, ((AbstractExpr)children.getFirst()).getValue());
    }


    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        Node index = children.getFirst();
        if (index instanceof Numeric) {
            // see if it is possible to use syntactic sugar
            switch(((Numeric)index).value) {
                case 0:
                    sb.append("MEMSIZE");
                    return sb;
                case 1:
                    sb.append("DEFENSE");
                    return sb;
                case 2:
                    sb.append("OFFENSE");
                    return sb;
                case 3:
                    sb.append("SIZE");
                    return sb;
                case 4:
                    sb.append("ENERGY");
                    return sb;
                case 5:
                    sb.append("PASS");
                    return sb;
                case 6:
                    sb.append("POSTURE");
                    return sb;
                default:
                    break;
            }
        }
        sb.append("mem[");
        index.prettyPrint(sb);
        sb.append("]");
        return sb;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof MemGet s)) {
            return false;
        }
        return token.equals(s.token) && children.getFirst().equals(s.getChildren().getFirst());
    }
}
