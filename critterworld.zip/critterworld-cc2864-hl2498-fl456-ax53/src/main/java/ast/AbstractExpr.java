package ast;

/** A critter program expression that has any number of children. */
public abstract class AbstractExpr extends AbstractNode {
    @Override
    public NodeCategory getCategory() {
        return NodeCategory.EXPRESSION;
    }

    public abstract int getValue();
}
