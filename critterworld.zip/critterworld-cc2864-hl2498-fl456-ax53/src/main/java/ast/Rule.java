package ast;

import parse.TokenType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** A representation of a critter rule. */
public class Rule extends AbstractNode {

    protected Node cond;
    protected ArrayList<Node> commands;

    /**
     * Create an AST representation of (condition) --> (1 or more commands)
     * <p> Requires: !commands.isEmpty(), contains only BinaryUpdate and Action nodes, children.getFirst() returns AbstractBinaryBool,
     *           and no more than 1 Action
     * @param cond binary condition
     * @param commands sequence of commands to execute if condition is true
     */
    public Rule(AbstractBinaryBool cond, ArrayList<Node> commands) {
        token = TokenType.ARR;
        this.cond = cond;
        this.cond.setParent(this);
        this.commands = (ArrayList<Node>) commands.clone();
        this.children.add(cond);
        for (Node com: commands){
            com.setParent(this);
            children.add(com);
        }
        if (!classInv()) {
            throw new IllegalArgumentException("Rule must have at least 1 command and at most 1 Action statement");
        }
    }

    protected Rule(){}

    public Node clone(){
        try {
            Node cond2 = cond.clone();
            ArrayList<Node> comm2 = new ArrayList<>();
            for (Node c : commands) {
                comm2.add(c.clone());
            }
            return new Rule((AbstractBinaryBool)cond2, comm2);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Elements of commands children are currently considered as children
    // Can be adjusted
    @Override
    public List<Node> getChildren(){
        children = new ArrayList<>();
        children.add(cond);
        children.addAll(commands);
        return children;
    }

    @Override
    public int size(){
        int sizeCommTree = 0;
        for (Node node : commands) {
            sizeCommTree += node.size();
        }
        return cond.size() + sizeCommTree + 1;
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        cond.prettyPrint(sb);
        sb.append(" --> ");
        boolean first = true;
        for (Node c : commands) {
            if (!first) {
                sb.append("\n    "); // use 4 spaces as indentation
            } else {
                first = false;
            }
            c.prettyPrint(sb);
        }
        return sb;
    }

    @Override
    public NodeCategory getCategory() {
        return NodeCategory.RULE;
    }

    @Override
    public boolean classInv() {
        // commands must contain BinaryUpdates and at most 1 Action
        boolean sawAction = false;
        for (Node c : commands) {
            if (c instanceof Action) {
                if (sawAction) return false;
                sawAction = true;
            } else if (!(c instanceof BinaryUpdate)) {
                return false;
            }
            if (!c.classInv()) {
                c.classInv();
                return false;
            }
        }
        if (cond instanceof AbstractBinaryBool && !commands.isEmpty()) {
            return cond.classInv();
        }
        return false;
    }

    /**
     * Returns true if there is an Action somewhere in this rule's sequence of commands.
     * @return true if there is an Action somewhere in this rule's sequence of commands.
     */
    public boolean hasAction() {
        for (Node c : commands) {
            if (c instanceof Action) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the TokenType of the action in this rule (if present). If this rule doesn't
     * contain an action, returns TokenType.WAIT.
     * @return the TokenType of the action in this rule (if present). If this rule doesn't
     * contain an action, returns TokenType.WAIT.
     */
    public TokenType getAction() {
        for (Node c : commands) {
            if (c instanceof Action) {
                return c.getToken();
            }
        }
        return TokenType.WAIT;
    }


    public ArrayList<Node> getCommands (){
        return commands;
    }

    public Node getCond(){
        return cond;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Rule r)) {
            return false;
        }
        List<Node> rules = r.commands;
        if (rules.size() != commands.size()) {
            return false;
        }
        return r.cond.equals(this.cond) && rules.equals(commands);
    }
}
