package ast;

import ast.Mutate.*;

/** A factory that produces the Mutation objects corresponding to each mutation */
public class MutationFactory {
    /**
     * Returns a new remove mutation object
     * @return mutation representing a remove
     */
    public static Mutation getRemove() {
        return new Remove();
    }
    /**
     * Returns a new remove swap object
     * @return mutation representing a swap
     */
    public static Mutation getSwap() {
        return new Swap();
    }

    /**
     * Returns a new replace mutation object
     * @return mutation representing a replace
     */
    public static Mutation getReplace() {
        return new Replace();
    }

    /**
     * Returns a new transform mutation object
     * @return mutation representing a transform
     */
    public static Mutation getTransform() {
        return new Transform();
    }
    /**
     * Returns a new insert mutation object
     * @return mutation representing a insert
     */
    public static Mutation getInsert() {
        return new Insert();
    }

    public static Mutation getDuplicate() {
        return new Duplicate();
    }

}
