package ast;

import model.Critter;
import parse.TokenType;

import java.util.HashMap;

public class InteractionHelper {
    private static final HashMap<Critter, ProgramImpl> critterProgramMap = new HashMap<>();
    private static final HashMap<ProgramImpl, Critter> programCritterMap = new HashMap<>();

    public static void updateMapping(Critter critter, ProgramImpl program) {
        if (critterProgramMap.containsKey(critter)){
            programCritterMap.remove(critterProgramMap.get(critter));
            critterProgramMap.remove(critter);
        }
        if (critterProgramMap.containsKey(critter)){
            critterProgramMap.remove(programCritterMap.get(program));
            programCritterMap.remove(program);
        }
        critterProgramMap.put(critter, program);
        programCritterMap.put(program, critter);
    }

    public static Critter getCritter(ProgramImpl program) {
        return programCritterMap.get(program);
    }

    public static ProgramImpl getProgram(Critter critter) {
        return critterProgramMap.get(critter);
    }

    public static boolean performActionWorld(TokenType action, Critter critter) {
        return false;
    }

    public static boolean performActionWorld(TokenType action) {
        return false;
    }

    public void attack(){

    }
}
