package ast;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

/** An abstract class representing an AST node with two children.
 * Invariant:must always have two non-null children nodes at all times
 */
public abstract class AbstractBinary extends AbstractNode {
    /**
     * Returns node category
     * @return node category of this node
     */
    @Override
    public NodeCategory getCategory() {
        return NodeCategory.CONDITION;
    }

    /**
     * Comapres whether two Abstract Binary Nodes are equal by comparing their children
     * @param o Abstract Binary Node to compare
     * @return true if they're equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof AbstractBinary)) {
            return false;
        }
        List<Node> list = ((AbstractBinary)o).getChildren();
        return ((AbstractBinary)o).token.equals(token) && children.get(1).equals(list.get(1))&&children.get(0).equals(list.get(0));
    }
}
