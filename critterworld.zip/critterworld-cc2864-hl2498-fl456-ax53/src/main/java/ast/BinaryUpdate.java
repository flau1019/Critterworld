package ast;

import model.Critter;
import parse.TokenType;

/**
 * A representation of a memory address update in a critter program.
 */
public class BinaryUpdate extends AbstractBinary {

    /**
     * Create an AST representation of memory update.
     * <p>Requires: left is instance of MemGet and is mutable, right is instance of AbstractExpr.
     * @param left memory address to update
     * @param right value to set the memory to
     */
    public BinaryUpdate(MemGet left, AbstractExpr right) {
        token = TokenType.ASSIGN;
        left.setParent(this);
        right.setParent(this);
        this.children.add(left);
        this.children.add(right);
    }

    // necessary for clone()
    protected BinaryUpdate() {}

    /**
     * Returns whether the AST under this node is well-formed. For use in assertions.
     */
    @Override
    public boolean classInv() {
        if (children.get(0) instanceof MemGet && children.get(1) instanceof AbstractExpr) {
            return children.get(0).classInv() && children.get(1).classInv();
        }
        return false;
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        children.get(0).prettyPrint(sb);
        sb.append(" := ");
        children.get(1).prettyPrint(sb);
        return sb;
    }

    public void setValue(int index, int value) {
        // TODO: implement it
        if (index > 0) {
        }
    }


    @Override
    public NodeCategory getCategory() {
        return NodeCategory.UPDATE;
    }
}
