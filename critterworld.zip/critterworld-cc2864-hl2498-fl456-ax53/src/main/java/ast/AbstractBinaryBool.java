package ast;

import parse.TokenType;

/** An abstract class representing a Boolean condition in a critter program. */
public abstract class AbstractBinaryBool extends AbstractBinary {

    public AbstractBinaryBool(){
    }

    public abstract boolean getValue();

    /**
     * Returns whether the AST under this node is well-formed. For use in assertions.
     */
    @Override
    public abstract boolean classInv();
}
