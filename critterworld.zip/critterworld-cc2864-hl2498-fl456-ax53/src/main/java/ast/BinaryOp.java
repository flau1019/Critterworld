package ast;

import parse.TokenCategory;
import parse.TokenType;

/** A representation of a binary Boolean condition: 'and' or 'or'
 * Invariant: both children must evaluate to a truth value
 * */
public class BinaryOp extends AbstractBinaryBool {

    /**
     * Create an AST representation of left op right.
     * <p>Requires: left and right are instances of AbstractBinaryBool, op is the "or" or "and" operator
     *
     * @param left first Boolean condition
     * @param op operation to perform
     * @param right second Boolean condition
     */
    public BinaryOp(TokenType op, AbstractBinaryBool left, AbstractBinaryBool right){
        if(!op.category().equals(TokenCategory.BINOP)){
            throw new IllegalArgumentException();
        }
        this.token = op;
        left.setParent(this);
        right.setParent(this);
        this.children.add(left);
        this.children.add(right);
    }

    public BinaryOp() {}

    private boolean left(){
        return ((AbstractBinaryBool)children.get(0)).getValue();
    }

    private boolean right(){
        return ((AbstractBinaryBool)children.get(1)).getValue();
    }

    /** Returns the value of current node */
    public boolean getValue(){
        return switch (token) {

            case OR  -> left() || right();
            case AND -> left() && right();

            default  -> throw new IllegalArgumentException("The BinaryOp has invalid token.");
        };
    }


    @Override
    public boolean classInv() {
        if (!token.category().equals(TokenCategory.BINOP)) {
            return false;
        }
        if (children.size() == 2 && children.get(0) instanceof AbstractBinaryBool && children.get(1) instanceof AbstractBinaryBool) {
            return children.get(0).classInv() && children.get(1).classInv();
        }
        return false;
    }

    /**
     * Prints a pretty BinaryOp
     * @param sb The {@code StringBuilder} to which the program will be appended
     * @return
     */
    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        printChild(false, children.get(0), sb);
        sb.append(" ").append(token.toString()).append(" ");
        printChild(true, children.get(1), sb);
        return sb;
    }


    /**
     * Calls pretty print on the given node, adding parentheses if needed.
     * @param checkingRight true if checking the right child.
     * @param node either the left or right child node of this object.
     * @param sb the StringBuilder to which the expression will be appended.
     * @return the StringBuilder to which this expression was appended.
     */
    private StringBuilder printChild(boolean checkingRight, Node node, StringBuilder sb) {
        boolean paren = needParentheses(checkingRight, node);
        if (paren) {
            if (!sb.isEmpty() && sb.charAt(sb.length()-1) != ' ') {
                sb.append(" ");
            }
            sb.append("{ ");
        }
        node.prettyPrint(sb);
        if (paren) {
            sb.append(" }");
        }
        return sb;
    }

    /**
     * Returns true if the given child node needs parentheses around it, otherwise false.
     * @param checkingRight true if checking the right child.
     * @param node either the left or right child node of this object.
     * @return true if the given child node needs parentheses around it, otherwise false.
     */
    private boolean needParentheses(boolean checkingRight, Node node) {
        if (!(node instanceof BinaryOp)) {
            return false;
        }
        if (checkingRight) {
            return true;
        }
        // Java order of operations: && takes precedence over ||
        return ((BinaryOp)node).token.equals(TokenType.OR) && token.equals(TokenType.AND);
    }
}
