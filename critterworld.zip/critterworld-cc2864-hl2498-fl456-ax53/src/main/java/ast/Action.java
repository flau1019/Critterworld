package ast;

import parse.TokenType;

import java.util.ArrayList;

/**
 * An action in a critter program.
 * Invariant: if the TokenType is SERVE, must only have one child, otherwise no children
 */
public class Action extends AbstractNode {

    /**
     * Creates an action in a critter program.
     * @param actionType type of action.
     */
    public Action(TokenType actionType) {
        if (actionType.equals(TokenType.SERVE)) {
            throw new IllegalArgumentException("Serve takes one numeric value as a parameter");
        }
        this.token = actionType;
        this.children = new ArrayList<>();
    }

    /**
     * Creates an Action node for Serve[expr]
     * @param actionType the token of this action
     * @param expr an AbstractExpr node for it's expr
     */

    public Action(TokenType actionType, AbstractExpr expr) {
        if (!actionType.equals(TokenType.SERVE)) {
            throw new IllegalArgumentException("This action doesn't take a numeric value");
        }
        this.token = actionType;
        this.children = new ArrayList<>();
        expr.setParent(this);
        children.add(expr);
    }

    public Action() {}

    /**
     * Perform the action represented by this node
     * @return whether the action is successfully performed
     */
    public boolean performAction(){

        return false;
    }

    /**
     * Prints a pretty node
     * @param sb The {@code StringBuilder} to which the program will be appended
     * @return sb of the node
     */

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        sb.append(token);
        if (token.equals(TokenType.SERVE)) {
            sb.append("[");
            children.getFirst().prettyPrint(sb);
            sb.append("]");
        }
        return sb;
    }

    /**
     * asserts the class invariant
     * @return true if it's unbroken, false otehrwisse
     */
    @Override
    public boolean classInv() {
        if (token.equals(TokenType.SERVE)) {
            return children.size() == 1 && (children.getFirst() instanceof AbstractExpr) && children.getFirst().classInv();
        }
        return children.isEmpty();
    }

    /**
     * Returns node category
     * @return node category
     */
    @Override
    public NodeCategory getCategory() {
        return NodeCategory.ACTION;
    }

    @Override
    public boolean equals(Object o){
        if (!(o instanceof Action)) {
            return false;
        }
        return token.equals(((Action) o).token) && children.equals(((Action) o).children);
    }

}