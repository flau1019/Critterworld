package ast;

import parse.TokenCategory;
import parse.TokenType;

/** A representation of a binary relation: <, <=, =, >=, >, != */
public class BinaryRel extends AbstractBinaryBool{

    /**
     * Create an AST representation of left op right.
     * <p>Requires: left and right are instances of AbstractExpr, op is a binary relation operator
     *
     * @param left first numeric value
     * @param op operation to perform
     * @param right second numeric value
     */
    public BinaryRel(TokenType op, AbstractExpr left, AbstractExpr right) {
        if (!op.category().equals(TokenCategory.RELOP)) {
            throw new IllegalArgumentException();
        }
        this.token = op;
        left.setParent(this);
        right.setParent(this);
        this.children.add(left);
        this.children.add(right);
    }

    public BinaryRel() {}

    private int left(){
        return ((AbstractExpr) children.get(0)).getValue();
    }

    private int right(){
        return ((AbstractExpr) children.get(1)).getValue();
    }

    /** Returns the value of current node */
    public boolean getValue(){
        return switch (token) {

            case LT -> left() <  right();
            case LE -> left() <= right();
            case EQ -> left() == right();
            case GE -> left() >= right();
            case GT -> left() >  right();
            case NE -> left() != right();

            default -> throw new IllegalArgumentException("The BinaryRel has invalid token.");
        };
    }

    @Override
    public boolean classInv() {
        if (!token.category().equals(TokenCategory.RELOP)) {
            return false;
        }
        if (children.size() == 2 && children.get(0) instanceof AbstractExpr && children.get(1) instanceof AbstractExpr) {
            return children.get(0).classInv() && children.get(1).classInv();
        }
        return false;
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        children.get(0).prettyPrint(sb);
        sb.append(" ");
        sb.append(token);
        sb.append(" ");
        children.get(1).prettyPrint(sb);
        return sb;
    }
}
