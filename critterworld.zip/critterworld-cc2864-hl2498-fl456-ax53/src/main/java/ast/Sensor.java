package ast;

import parse.TokenCategory;
import parse.TokenType;

import java.util.ArrayList;

/**
 * A representation of a sensor in a critter program.
 */
public class Sensor extends AbstractRetrieve{

    /**
     * Constructs an AST node representing the sensor type SMELL
     * <p>Requires: type is SMELL, as it's the only sensor without an argument
     * @param type is the TokenType to create
     */

    public Sensor(TokenType type){
        if (!type.equals(TokenType.SMELL)) {
            throw new IllegalArgumentException("Non Smell Sensors must have an AbstractExpr Argument");
        }
        this.token = type;
        children = new ArrayList<>();
    }

    public Sensor() {}

    /**
     * Constructs an AST node representing the sensor type[argument]
     * <p>Requires: type is a sensor type, argument evaluates to a numerical value.
     * @param argument argument passed to the sensor.
     */

    public Sensor(TokenType type, AbstractExpr argument) {
        if (!type.category().equals(TokenCategory.SENSOR)) {
            throw new IllegalArgumentException("Argument must evaluate to a numeric value");
        }
        if (type.equals(TokenType.SMELL)) {
            throw new IllegalArgumentException("Smell does not take any parameters");
        }
        this.token = type;
        children = new ArrayList<>();
        argument.setParent(this);
        children.add(argument);
    }

    /**
     * Returns whether the AST under this node is well-formed. For use in assertions.
     */
    @Override
    public boolean classInv() {
        if (token.equals(TokenType.SMELL)) {
            return children.isEmpty();
        }
        if (token.category().equals(TokenCategory.SENSOR) && children.size() == 1) {
            return (children.getFirst() instanceof AbstractExpr) && children.getFirst().classInv();
        }
        return false;
    }

    @Override
    public StringBuilder prettyPrint(StringBuilder sb) {
        sb.append(token);
        if (!token.equals(TokenType.SMELL)){
            sb.append("[");
            children.getFirst().prettyPrint(sb);
            sb.append("]");
        }
        return sb;
    }


    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Sensor s)) {
            return false;
        }
        if (token.equals(TokenType.SMELL) && s.token.equals(TokenType.SMELL)) {
            return true;
        }
        return token.equals(s.token) && children.getFirst().equals(s.getChildren().getFirst());
    }

    @Override
    public int getValue() {
        return 0;
    }
}