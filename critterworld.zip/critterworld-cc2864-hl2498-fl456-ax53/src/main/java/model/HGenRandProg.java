package model;

import ast.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Random;

public class HGenRandProg {
    private static final Random random = new Random();
    private static final String[] actions = {"wait", "forward", "backward", "left", "right", "eat", "attack", "grow", "bud", "mate"};
    private static final String[] sensors = {"nearby[expr]", "ahead[expr]", "random[expr]", "smell"};
    private static final String[] binaryRel = {"<", "<=", "=", ">=", ">", "!="};
    private static final String[] addOp = {"+", "-"};
    private static final String[] mulOp = {"*", "/", "mod"};
    private static final String[] numeric = {"1", "2", "3", "4", "5", "19", "21", "12", "13", "8", "9"};

    public static void genRandProgram(Map<Class<? extends Node>, Integer> ec) {
        File program = new File("src/test/resources/files/validPrograms/randProgram.txt");

        try (FileWriter fileWriter = new FileWriter(program)) {
            int flag = random.nextInt(1, 7);
            for (int i = 0; i < flag; i++) {
                if (i == flag - 1) {
                    fileWriter.write(genRule(ec));
                } else {
                    fileWriter.write(genRule(ec) + '\n');
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    public static String genRandProgramString(Map<Class<? extends Node>, Integer> ec) {
        StringBuilder sb = new StringBuilder();
        int flag = random.nextInt(1, 7);
        for (int i = 0; i < flag; i++) {
            if (i == flag - 1) {
                sb.append(genRule(ec));
            } else {
                sb.append(genRule(ec)).append('\n');
            }
        }
        return sb.toString();
    }

    private static String genRule(Map<Class<? extends Node>, Integer> ec) {
        updateMap(ec, Rule.class);
        return genCondition(ec) + " --> " + genCommand(ec);
    }

    private static StringBuilder genCondition(Map<Class<? extends Node>, Integer> ec) {
        StringBuilder totalConj = new StringBuilder();
        int flag = random.nextInt(100);
        if (flag < 90) {
            totalConj.append(genConj(ec));
        } else {
            updateMap(ec, BinaryOp.class);
            totalConj.append(genConj(ec)).append(" or ").append(genConj(ec));
        }
        return totalConj;
    }

    private static StringBuilder genCommand(Map<Class<? extends Node>, Integer> ec) {
        StringBuilder tc = new StringBuilder();
        int flag = random.nextInt(100);
        int numUpdates = random.nextInt(2, 5);
        if (flag < 90) {
            for (int i = 1; i < numUpdates; i++) {
                if (i == numUpdates - 1) {
                    tc.append(genUpdate(ec)).append(";");
                } else {
                    tc.append(genUpdate(ec)).append("\n\t");
                }
            }
        } else {
            for (int i = 0; i < numUpdates; i++) {
                tc.append(genUpdate(ec)).append("\n\t");
            }
            tc.append(genAction(ec)).append(";");
        }
        return tc;
    }

    private static String genUpdate(Map<Class<? extends Node>, Integer> ec) {
        updateMap(ec, BinaryUpdate.class);
        return genFac(ec, 1) + " := " + genExpr(ec);
    }

    private static String genAction(Map<Class<? extends Node>, Integer> ec) {
        updateMap(ec, Action.class);
        return actions[random.nextInt(actions.length)];
    }

    private static String genConj(Map<Class<? extends Node>, Integer> ec) {
        int flag = random.nextInt(100);
        if (flag < 90) {
            return genRel(ec);
        } else {
            updateMap(ec, BinaryOp.class);
            return genRel(ec) + " and " + genRel(ec);
        }
    }

    private static String genRel(Map<Class<? extends Node>, Integer> ec) {
        updateMap(ec, BinaryRel.class);
        return genExpr(ec) + " " + binaryRel[random.nextInt(binaryRel.length)] + " " + genExpr(ec);
    }

    private static String genExpr(Map<Class<? extends Node>, Integer> ec) {
        int flag = random.nextInt(100);
        if (flag < 90) {
            return genT(ec);
        } else {
            updateMap(ec, BinaryNumeric.class);
            return genT(ec) + " " + addOp[random.nextInt(addOp.length)] + " " + genT(ec);
        }
    }

    private static String genT(Map<Class<? extends Node>, Integer> ec) {
        int flag = random.nextInt(100);
        if (flag < 90) {
            return genF(ec);
        } else {
            updateMap(ec, BinaryNumeric.class);
            return genF(ec) + " " + mulOp[random.nextInt(mulOp.length)] + " " + genF(ec);
        }
    }

    private static String genF(Map<Class<? extends Node>, Integer> ec) {
        int flag = random.nextInt(7);
        return genFac(ec, flag);
    }

    private static String genFac(Map<Class<? extends Node>, Integer> ec, int type) {
        switch (type) {
            case 0:
                updateMap(ec, Numeric.class);
                return numeric[random.nextInt(numeric.length)];
            case 1:
                updateMap(ec, MemGet.class);
                return "mem[" + genExpr(ec) + "]";
            case 2:
                return "(" + genExpr(ec) + ")";
            case 3:
                return "-" + genFac(ec, 0);
            case 4:
                return genSensor(ec);
            case 5:
                return "-(" + genExpr(ec) + ")";
            case 6:
                return "-" + genExpr(ec);
            default:
                throw new IndexOutOfBoundsException("generate factor index out of bounds");
        }
    }

    private static String genSensor(Map<Class<? extends Node>, Integer> ec) {
        updateMap(ec, Sensor.class);
        String sensor = sensors[random.nextInt(sensors.length)];

        if (sensor.contains("expr")) {
            sensor = sensor.replace("expr", genExpr(ec));
            return sensor;
        }
        return sensor;
    }

    private static void updateMap(Map<Class<? extends Node>, Integer> ec, Class<? extends Node> target) {
        int temp = ec.getOrDefault(target, 0);
        temp++;
        ec.put(target, temp);
    }
}
