package model;

import ast.Program;
import ast.ProgramImpl;
import ast.Rule;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import parse.TokenType;

/**
 * TODO documentation
 */
public class Interpreter {
    private final Critter critter;
    private final ProgramImpl program;

    public Interpreter(Critter critter, ProgramImpl program) {
        this.critter = critter; // can't make a copy of critter b/c we modify its state when running the program
        this.program = (ProgramImpl) program.clone(); // make a copy to be safe
    }

    /**
     *
     * @return the last rule that is executed.
     */
    public Maybe<Rule> runProgram() {
        Maybe<Rule> lastRule = Maybe.none();
        while (critter.retrieve(TokenType.MEM, 5) < Constants.MAX_RULES_PER_TURN) {
            Maybe<Rule> result = Maybe.none(); // TODO result = program.runProgram(critter);
            try {
                Rule rule = result.get();
                if (rule.hasAction()) {
                    return result;
                } else {
                    // increment PASS by 1
                    critter.memUpdate(5, critter.retrieve(TokenType.MEM, 5)+1);
                    lastRule = result;
                }
            } catch (NoMaybeValue e) {
                critter.Wait();
                return lastRule;
            }
        }
        critter.Wait();
        return lastRule;
    }

    /**
     *
     * @return current program string of the critter contained in this object.
     */
    public String getProgramString() {
        return program.toString();
    }

    /**
     *
     * @return a copy of current program of the critter contained in this object.
     */
    public Program getProgram() {
        return (Program) program.clone();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Interpreter t)) {
            return false;
        }
        return program.equals(t.program); // don't need to compare critters b/c interpreter.equals() is called within critter.equals()
    }

    /**
     * Returns the number of rules in this program.
     * @return the number of rules in this program.
     */
    public int getNumberOfRules() {
        return program.getChildren().size();
    }
}
