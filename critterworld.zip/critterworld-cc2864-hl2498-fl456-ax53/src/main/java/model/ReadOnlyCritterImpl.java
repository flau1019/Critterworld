package model;

import cms.util.maybe.Maybe;

public class ReadOnlyCritterImpl implements ReadOnlyCritter{
    @Override
    public String getSpecies() {
        return "";
    }

    @Override
    public int[] getMemory() {
        return new int[0];
    }

    @Override
    public String getProgramString() {
        return "";
    }

    @Override
    public Maybe<String> getLastRuleString() {
        return null;
    }
}
