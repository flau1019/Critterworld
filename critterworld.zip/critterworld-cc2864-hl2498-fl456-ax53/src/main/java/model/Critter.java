package model;

import ast.Program;
import ast.ProgramImpl;
import ast.Rule;
import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import easyIO.BacktrackScanner;
import exceptions.SyntaxError;
import parse.ParserFactory;
import parse.Parser;
import parse.TokenType;

import java.io.Reader;
import java.io.StringReader;
import java.util.*;

import static model.Constants.*;

public class Critter extends ReadOnlyCritterImpl {
    private String species;
    private int[] memory;
    private Interpreter interpreter;
    private Maybe<Rule> lastRule;
    private CritterWorldImpl world;
    private CritterLocation location;

    public Critter() {
        this(null, 0, 0, 0, 0, 0, 0, null);
    }

    /**
     * Creates a Critter with the provided data. If the provided parameters are null or out-of-bounds,
     * they are set to random in-bounds values.
     * @param species name of the critter, for display purposes only. If null, this is set to a default name.
     * @param memsize size of the critter's memory, at least 7.
     * @param defense defense stat, at least 1.
     * @param offense offense stat, at least 1.
     * @param size size of the Critter, at least 1.
     * @param energy energy level of the Critter, at least 1.
     * @param posture posture of the Critter, at least 0 and at most 99.
     * @param program critter program that defines this critter's logic. If null, the critter is given a random program.
     */
    public Critter(String species, int memsize, int defense, int offense, int size, int energy, int posture, Program program) {
        this.species = Objects.requireNonNullElse(species, "CS2112 sweat");
        Random rand = new Random();
        if (memsize < 7) {
            memsize = rand.nextInt(7, 101);
        }
        if (defense < 1) {
            defense = rand.nextInt(1, 101);
        }
        if (offense < 1) {
            offense = rand.nextInt(1, 101);
        }
        if (size < 1) {
            size = rand.nextInt(1, 101);
        }
        if (energy < 1) {
            energy = rand.nextInt(100, 501);
        }
        if (posture < 0 || posture > 99) {
            posture = rand.nextInt(0, 100);
        }
        memory = new int[memsize];
        memory[0] = memsize;
        memory[1] = defense;
        memory[2] = offense;
        memory[3] = size;
        memory[4] = energy;
        memory[5] = 0; // pass is 0 by default
        memory[6] = posture;

        if (program == null){
            String prog = HGenRandProg.genRandProgramString(new HashMap<>());
            Reader r = new StringReader(prog);
            Parser parser = ParserFactory.getParser();
            try {
                program = parser.parse(r);
            } catch (SyntaxError e) {
                System.out.println("Syntax error when generating random program");
            }
        }
        assert program != null;
        interpreter = new Interpreter(this, (ProgramImpl)program);
    }

    public TokenType runProgram() {
        lastRule = interpreter.runProgram();
        TokenType action = null;
        try {
            action = (lastRule.get()).getAction();
        } catch (NoMaybeValue ignored) { }
        return (action != null) ? action : TokenType.WAIT;
    }

    @Override
    public String getSpecies() {
        return species;
    }

    @Override
    public int[] getMemory() {
        // creates copy of memory to avoid rep exposure
        int[] mem2 = new int[memory.length];
        System.arraycopy(memory, 0, mem2, 0, memory.length);
        return mem2;
    }

    @Override
    public String getProgramString() {
        return interpreter.getProgramString();
    }

    @Override
    public Maybe<String> getLastRuleString() {
        try {
            return Maybe.some(lastRule.get().toString());
        } catch (NoMaybeValue e) {
            return Maybe.none();
        }
    }

    /**
     * Updates the energy of the critter by the specified amount, capping at
     * size x ENERGY_PER_SIZE (= 500) points of energy. If the critter's energy becomes
     * less than or equal to 0 due to this update, the critter will die.
     * @param e amount by which to change the energy (positive or negative)
     * @return true if the critter is alive after this update, false if it died.
     */
    public boolean updateEnergy(int e) {
        memory[4] = Math.min(memory[4] + e, memory[3] * Constants.ENERGY_PER_SIZE);
        return memory[4] > 0;
    }

    public int getComplexity() {
        return interpreter.getNumberOfRules() * RULE_COST + (memory[2] + memory[1]) * ABILITY_COST;
    }

    /**
     * Performs the update mem[expr] := value, if legal. Otherwise does nothing.
     * @param expr the target index of memory
     * @param value the value
     */
    public void memUpdate(int expr, int value) {
        if (expr > 6 || (expr == 6 && value >= 0 && value <= 99)) {
            memory[expr] = value;
        }
    }

    /**
     *
     * @param token
     * @param expr the target index of memory
     * @return the value of memory
     */
    // TODO implement
    public int retrieve(TokenType token, int expr) {
        switch (token) {
            case TokenType.MEM:
                return (expr >= 0 && expr < memory[0]) ? memory[expr] : 0;
            case TokenType.NEARBY:
                break; // TODO
            case TokenType.AHEAD:
                break; // TODO
            case TokenType.RANDOM:
                return (expr > 1) ? (new Random()).nextInt(expr) : 0;
        }
        return 0;
    }

    public void Wait() { //this is spelled Wait because there's a wait method in object class
        updateEnergy(getSize());
    }

    public int smell() {
        // TODO Most complicated one so doing last
        return 0;
    }

    /**
     * Moves to the next hex in the direction the critter is facing if success is true.
     * Otherwise, does not move and subtracts the same amount of energy.
     * @param success whether this move will be successful or not.
     * @return true if the critter is still alive after this action, false if the critter died.
     */
    public boolean forward(boolean success) {
        if (!updateEnergy(-getSize() * Constants.MOVE_COST)) {
            return false;
        }
        if (success) {
            location.goForward();
        }
        return true;
    }

    /**
     * Moves to the next hex opposite to the direction the critter is facing if success is true.
     * Otherwise, does not move and subtracts the same amount of energy.
     * @param success whether this move will be successful or not.
     * @return true if the critter is still alive after this action, false if the critter died.
     */
    public boolean backward(boolean success) {
        if (!updateEnergy(-getSize() * Constants.MOVE_COST)) {
            return false;
        }
        if (success) {
            location.goBackward();
        }
        return true;
    }

    /**
     * Returns the amount of food left over after the critter eats as much as it can,
     * or -1 if the critter ran out of energy when attempting to eat.
     * @param food amount of food available to eat.
     * @param success if the action will be successful.
     * @return the amount of food left over after the critter eats as much as it can,
     * or -1 if the critter ran out of energy when attempting to eat.
     */
    public int eat(int food, boolean success) {
        updateEnergy(-getSize());
        if (success && food > 0) {
            if (getEnergy() <= 0) {
                return -1;
            }
            int maxEnergy = getSize() * ENERGY_PER_SIZE, prevEnergy = getEnergy();
            memory[4] = Math.min(maxEnergy, prevEnergy + food);
            return Math.min(food, maxEnergy - prevEnergy);
        } else {
            return getEnergy() <= 0 ? -1 : 0;
        }
    }

    /**
     * Turns the critter in the specified direction.
     * @param isRight true to turn right, false to turn left.
     * @return true if the critter is alive after this action.
     */
    public boolean turn(boolean isRight) {
        if (isRight) {
            location.turnRight();
        } else {
            location.turnLeft();
        }
        // turning doesn't affect the world state, so it doesn't matter whether
        // we update energy before or after the "turn" action
        return updateEnergy(-getSize());
    }

    /**
     * Critter loses energy through budding. Returns true if the critter is alive after
     * budding, otherwise false.
     * @return true if the critter is alive after budding, otherwise false.
     */
    public boolean bud() {
        return updateEnergy(-getSize() * getComplexity() * BUD_COST);
    }

    /**
     * Returns a bud of this critter, possibly with mutations.
     * @return a bud of this critter, possibly with mutations.
     */
    public Critter budCritter() {
        Random rand = new Random();
        // copy over inherited attributes: memsize, defense, and offense
        int[] memCopy = new int[3];
        for (int i = 0; i < 3; i++) {
            memCopy[i] = memory[i];
        }
        Program program = interpreter.getProgram();
        // 1/4 chance of mutation
        while (rand.nextInt(4) == 0) {
            if (rand.nextBoolean()) {
                int idx = rand.nextInt(3), min = 1;
                if (idx == 0) {
                    min = 7;
                }
                // if greater than minimum possible value, random chance to +1 or -1
                // otherwise, can only +1
                memCopy[idx] = (memCopy[idx] > min) ? ((rand.nextBoolean()) ? -1 : 1) : 1;
            } else {
                program.mutate();
            }
        }
        return new Critter(species, memCopy[0], memCopy[1], memCopy[2], 1, 250, 0, program);
    }

    public void mate(Critter c) {

    }

    public boolean attack() {
        return updateEnergy(-getSize() * ATTACK_COST);
    }

    public boolean grow() {
        if(updateEnergy(-getSize() * getComplexity() * GROW_COST)){
            memory[3]++;
            return true;
        }
        else{ //The critter dead so I'm assuming its not active anymore
            return false;
        }
    }

    public void serve(int expr) {

    }

    public int getDefense(){
        return memory[1];
    }

    public int getOffense(){
        return memory[2];
    }

    public int getSize(){
        return memory[3];
    }

    public int getEnergy(){
        return memory[4];
    }

    public int getPosture(){
        return memory[6];
    }

    public void setHexPosition(int col, int row, int dir) {
        location = new CritterLocation(col, row, dir);
    } //The critter has to know where it is to be able to update its location

    public CritterLocation getLocation() {
        return location;
    }

    public void setPosture(Integer d){
        memory[6] = d;
    }

    public void setWorld(CritterWorldImpl world){
        this.world = world;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Critter c)) {
            return false;
        }
        return species.equals(c.species) && Arrays.equals(memory, c.memory) && interpreter.equals(c.interpreter);
    }

}
