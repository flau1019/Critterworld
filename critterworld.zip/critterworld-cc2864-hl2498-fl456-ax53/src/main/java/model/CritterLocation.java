package model;

/**
 * Represents the location of a critter in the world, both as a hex location
 * and array index.
 */
public class CritterLocation {
    private int hexCol, hexRow, arrayCol, arrayRow, direction;

    public CritterLocation(int col, int row, int dir) {
        setLocation(col, row);
        setDirection(dir);
    }

    /**
     * Sets the location to the provided hex coordinates and updates the array
     * coordinates to match.
     * @param col hex column.
     * @param row hex row.
     */
    public void setLocation(int col, int row) {
        hexCol = col;
        hexRow = row;
        if (col % 2 == 0) {
            arrayRow = row/2;
        }
        else {
            arrayRow = (row-1)/2;
        }
        arrayCol = col;
    }

    /**
     * Sets the direction to the specified value modulo 6.
     * @param dir the new direction.
     */
    public void setDirection(int dir) {
        direction = dir % 6; // ensure direction is in bounds
    }

    /**
     * Rotate the direction to the left.
     */
    public void turnLeft() {
        setDirection(((direction - 1) + 6) % 6);
    }

    /**
     * Rotate the direction to the right.
     */
    public void turnRight() {
        setDirection((direction + 1) % 6);
    }

    /**
     * Changes the coordinates of this CritterLocation to be one hex grid forwards
     * in the direction it is facing.
     */
    public void goForward() {
        switch (direction) {
            case 0:
                setLocation(hexCol, hexRow+2);
            case 1:
                setLocation(hexCol+1, hexRow+1);
            case 2:
                setLocation(hexCol+1, hexRow-1);
            case 3:
                setLocation(hexCol, hexRow-2);
            case 4:
                setLocation(hexCol-1, hexRow-1);
            case 5:
                setLocation(hexCol-1, hexRow+1);
        }
    }

    // USE THE RETURNED COORDINATES TO TEST IF A POSITION IS VALID BEFORE MOVING TO IT

    /**
     * Returns the coordinates of this object after a goForward() call, without actually moving forward.
     * @return the coordinates of this object after a goForward() call, without actually moving forward.
     */
    public CritterLocation stepForward() {
        CritterLocation step = new CritterLocation(hexCol, hexRow, direction);
        step.goForward();
        return step;
    }

    /**
     * Changes the coordinates of this CritterLocation to be one hex grid backwards
     * in the direction it is facing.
     */
    public void goBackward() {
        // turning 180 degrees, moving forward, then turning 180 degrees again
        setDirection((direction + 3) % 6);
        goForward();
        setDirection((direction + 3) % 6);
    }

    /**
     * Returns the coordinates of this object after a goBackward() call, without actually moving backward.
     * @return the coordinates of this object after a goBackward() call, without actually moving backward.
     */
    public CritterLocation stepBackward() {
        CritterLocation step = new CritterLocation(hexCol, hexRow, direction);
        step.goBackward();
        return step;
    }

    /**
     *
     * @return the column of this location in hex coordinates.
     */
    public int getHexCol() {
        return hexCol;
    }

    /**
     *
     * @return the row of this location in hex coordinates.
     */
    public int getHexRow() {
        return hexRow;
    }

    /**
     *
     * @return the column of this location in array coordinates.
     */
    public int getArrCol() {
        return arrayCol;
    }

    /**
     *
     * @return the row of this location in array coordinates.
     */
    public int getArrRow() {
        return arrayRow;
    }

    /**
     *
     * @return the direction this location is facing in.
     */
    public int getDirection() {
        return direction;
    }
}
