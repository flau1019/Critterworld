package model;

import ast.Mutation;
import parse.TokenType;

import java.util.*;

public class CritterWorldImpl {
    private String name;
    private int inputRow; //Needed for printing out world
    private int mapRow, mapCol;
    private List<Critter> activeCritters = new ArrayList<>(); // U to initialize it because wihtout it, it's a null pointer exception
    private Optional<Object>[][] map; // TODO should we change this to Maybe? that's what they wanted us to use for all the A4 stuff-
    boolean enableManna, enableForcedMutation;
    private int iteration = 0;
    private HashMap<Critter, CritterLocation> critterHexes = new HashMap<>();

    public CritterWorldImpl() {
        this("World", 0, 0, true, false);
        randomPopulation();
    }

    public CritterWorldImpl(String name, int hexCols, int hexRows, boolean enableManna, boolean enableForcedMutation) {
        this.name = name;

        // if world dimensions out of bounds, sets it to a random dimension between 1-100
        Random rand = new Random();
        if (hexCols <= 0) {
            hexCols = rand.nextInt(1, 101);
        }
        if (hexRows <= 0) {
            hexRows = rand.nextInt(1, 101);
        }

        this.mapCol = hexCols;
        this.inputRow = hexRows;
        this.mapRow = (hexRows / 2) + 1; //need to plus one cuz missing a row in array

        map = new Optional[mapRow][mapCol];
        initializeValues(mapCol, mapRow);

        this.enableManna = enableManna;
        this.enableForcedMutation = enableForcedMutation;
    }

    /**
     * Randomly adds objects to the world, choosing between a rock, food between 1-1000 in value,
     * and a randomly generated critter.
     */
    public void randomPopulation() {
        Random rand = new Random();
        int num = rand.nextInt(1, (mapRow * 2 * mapCol) + 1);
        for (int i = 0; i < num; i++) {
            switch (rand.nextInt(6)) {
                // TODO
                // Fix the bug where intputting the value adds to the 2d array as divided by 2
                case 0:
                    addRocks(rand.nextInt(mapCol), rand.nextInt(mapRow));
                    break;
                case 1:
                    addFood(rand.nextInt(mapCol), rand.nextInt(mapRow), rand.nextInt(1, 1001));
                    break;
                case 2:
                    addCritter(new Critter(), rand.nextInt(mapCol), rand.nextInt(mapRow), rand.nextInt(6));
            }
        }
    }

    /**
     * Checks if the map is empty at map[row][col]
     *
     * @return true if there exists an Optional object at the specified location, false otherwise
     */
    public boolean isEmpty(int row, int col) {
        return !map[row][col].isPresent();
    }

    public boolean isEmpty() {
        for (int i = 0; i < mapRow; i++) {
            for (int j = 0; j < mapCol; j++) {
                if (map[i][j].isPresent()) return false;
            }
        }
        return true;
    }


    /**
     * Instantiates a rock into the critterWorld map at a specified hex location if and only if the map is empty at said location
     *
     * @param col, col hex-coordinate of the rock to be added
     * @param row, row hex-coordinate of the rock to be added
     */
    public void addRocks(int col, int row) {
        if (!addToWorld(col, row, Constants.ROCK_VALUE)) {
            System.out.println("Cannot add rock to a non-empty hex-grid");
        }
    }

    /**
     * Instantiates food into the critterWorld map at a specified hex location if and only if
     * the map is empty at said location
     *
     * @param col,  col hex-coordinate of the food to be added
     * @param row,  row hex-coordinate of the food to be added
     * @param food, amount of food to add
     */
    public void addFood(int col, int row, int food) {
        if (!addToWorld(col, row, -(food + 1))) {
            System.out.println("Cannot add food to a non-empty hex-grid");
        }
    }

    /**
     * Instantiates a critter into the critterWorld map at a specified hex location and adds it to the list of activeCritters if and
     * only if the map is empty at said location
     *
     * @param critter, critter to add
     * @param col,     col hex-coordinate of the critter to be added
     * @param row,     row hex-coordinate of the critter to be added
     * @param direction, direction of the critter
     */
    public void addCritter(Critter critter, int col, int row, int direction) {
        if (addToWorld(col, row, critter)) {
            critter.setWorld(this);
            critter.setHexPosition(col, row, direction);
            critterHexes.put(critter, critter.getLocation());
            activeCritters.add(critter);
        } else {
            System.out.println("Cannot add critter in an non-empty hex grid");
        }

    }


    /**
     * A list of active critters in the world in the order of their instantiation into the world
     *
     * @return list of critters
     */
    public List<Critter> getActiveCritters() {
        return activeCritters;
    }

    /**
     * Constructs a read only version of the critter world
     *
     * @return a new ReadOnlyWorldImpl object
     */
    public ReadOnlyWorldImpl readOnly() {
        return new ReadOnlyWorldImpl(this);
    }

    /**
     * Getter method for the current Iteration
     *
     * @return integer value of the current iteration of the world
     */
    public int getIteration() {
        return iteration;
    }

    /**
     * Advances the world's iteration count for simulating turns
     */

    public void nextIteration() {
        iteration++;
        for (Critter critter : activeCritters) {
            TokenType action = critter.runProgram();
            switch (action) {
                // TODO add all actions
                case TokenType.WAIT:
                    critter.Wait();
                case TokenType.FORWARD:
                    forward(critter);
                case TokenType.BACKWARD:
                    backward(critter);
                case TokenType.LEFT:
                    turn(critter, false);
                case TokenType.RIGHT:
                    turn(critter, true);
                case TokenType.EAT:
                    eat(critter);
                case TokenType.SERVE:
                    break; // TODO need a way to track the amount served
                case TokenType.ATTACK:
                    attack(critter);
                case TokenType.GROW:
                    grow(critter);
                case TokenType.BUD:
                    bud(critter);
                case TokenType.MATE:
                    break;
            }
        }
    }

    private void turn(Critter c, boolean isRight) {
        if (!c.turn(isRight)) {
            removeCritter(c);
        }
    }

    private void forward(Critter c) {
        CritterLocation location = critterHexes.get(c);
        CritterLocation step = location.stepForward();
        if (!c.forward(isInBounds(step) && map[step.getArrRow()][step.getArrCol()].isEmpty())) {
            removeCritter(c);
        }
    }

    private void backward(Critter c) {
        CritterLocation location = critterHexes.get(c);
        CritterLocation step = location.stepBackward();
        if (!c.backward(isInBounds(step) && map[step.getArrRow()][step.getArrCol()].isEmpty())) {
            removeCritter(c);
        }
    }

    private void grow(Critter c) {
        if (!c.grow()) {
            removeCritter(c);
        }
    }

    private void eat(Critter c) {
        CritterLocation step = critterHexes.get(c).stepForward();
        if (isInBounds(step) && map[step.getArrRow()][step.getArrCol()].isPresent()) {
            int food = (Integer)(map[step.getArrRow()][step.getArrCol()].get());
            if (c.eat(-food - 1, true) < 0) {
                removeCritter(c);
            }
        } else {
            if (c.eat(0, false) < 0) {
                removeCritter(c);
            }
        }
    }

    private void attack(Critter c) {
        CritterLocation step = critterHexes.get(c).stepForward();
        if (isInBounds(step) && map[step.getArrRow()][step.getArrCol()].isPresent() && map[step.getArrRow()][step.getArrCol()].get() instanceof Critter) {
            Critter other = (Critter)(map[step.getArrRow()][step.getArrCol()].get());
            boolean survived = other.updateEnergy((int) -Math.round(Constants.BASE_DAMAGE * c.getSize() * logistic(Constants.DAMAGE_INC * c.getSize() * c.getOffense() - other.getSize() * other.getDefense())));
            if (!survived) {
                removeCritter(other);
            }
        }
        if (!c.attack()) {
            removeCritter(c);
        }
    }

    private double logistic(double expr) {
        return 1 / (1 + Math.exp(-expr));
    }

    private void bud(Critter c) {
        CritterLocation step = c.getLocation().stepBackward();
        if (!c.bud()) {
            removeCritter(c);
        } else if (isInBounds(step) && map[step.getArrRow()][step.getArrCol()].isEmpty()) {
            Critter bud = c.budCritter();
            addCritter(bud, step.getHexCol(), step.getHexRow(), step.getDirection());
        }
    }

    /**
     * Removes a critter from the simulation, used when a critter has died.
     * @param c critter to remove.
     */
    private void removeCritter(Critter c) {
        activeCritters.remove(c);
        CritterLocation location = critterHexes.remove(c);
        map[location.getArrRow()][location.getArrCol()] = Optional.empty();
        addFood(location.getHexCol(), location.getHexRow(), c.getSize() * Constants.FOOD_PER_SIZE);
    }

    /**
     * Returns true if the location is within bounds of the map array, otherwise false.
     * @param location array coordinates (NOT HEX COORDINATES).
     * @return true if the location is within bounds of the map array, otherwise false.
     */
    private boolean isInBounds(CritterLocation location) {
        int col = location.getArrCol(), row = location.getArrRow();
        return (col >= 0 && col < getMapCol() && row >= 0 && row < getMapRow());
    }

    public int getMapRow() {
        return mapRow;
    }

    public int getMapCol() {
        return mapCol;
    }

    public int getInputRow(){
        return inputRow;
    }

    public Optional<Object>[][] getMap() {
        return map.clone();
    }

    /**
     * Adds an Object o in a hex-coordinate to its respective position in the 2d critterWorld array if
     * and only if the array is empty at said location
     *
     * @param col, col hex-coordinate of the object to add
     * @param row, row hex-coordinate of the object to add
     * @param o,   object to add
     */

    private boolean addToWorld(int col, int row, Object o) {
        /*
        Shouldn't it be checking is (cow + row)%2 because that's the one we divided by 2
        Like for the example of 3 3, it should be put into the map as [1][3]
        3 3 is a valid input because it's not in a line versus something like 2  3
        But instead it goes into the else statement. It still goes into [1][3] but feels a little off
        */

        if (col % 2 == 0) {
            if (isEmpty(row / 2, col)) {
                map[row / 2][col] = Optional.of(o);
                return true;
            }
        } else {
            if (isEmpty(row / 2, col)) {
                map[(row - 1) / 2][col] = Optional.of(o);
                return true;
            }
        }
        return false;
    }

    public void removeFromWorld(int col, int row) {
        if (col % 2 == 0) {
            map[row / 2][col] = Optional.empty();
        } else {
            map[(row - 1) / 2][col] = Optional.empty();
        }
    }

    /**
     * Initializes the critterWorld array with optional empty objects to avoid null pointer exceptions with an empty tile
     *
     * @param col number of cols
     * @param row number of rows
     */
    private void initializeValues(int col, int row) {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                map[i][j] = Optional.empty();
            }
        }
    }

}

