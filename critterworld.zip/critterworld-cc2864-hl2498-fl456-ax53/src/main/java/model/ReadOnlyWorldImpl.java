package model;

import cms.util.maybe.Maybe;

import java.util.Optional;

public class ReadOnlyWorldImpl implements ReadOnlyWorld{

    CritterWorldImpl world;
    
    public ReadOnlyWorldImpl(CritterWorldImpl world){
        this.world = world;
    }

    @Override
    public int getSteps() {
        return world.getIteration();
    }

    @Override
    public int getNumberOfAliveCritters() {
        return world.getActiveCritters().size();
    }

    @Override
    public Maybe<ReadOnlyCritter> getReadOnlyCritter(int c, int r) {
//        if(world.map[r][c] instanceof Critter){
//            return (Maybe<ReadOnlyCritter>) world.map[r][c]; //ngl im confused about this
//        }
//        return null;
        return null;
    }

    @Override
    public int getTerrainInfo(int c, int r) {
        Optional<Object> terrain = world.getMap()[r][c];

        if (terrain.isPresent()) {
            Object obj = terrain.get();
            if (obj instanceof Integer) {
                return (int) obj;
            } else if (obj instanceof Critter) {
                return ((Critter) obj).getPosture();
            }
        }
        return 0;
    }
}
