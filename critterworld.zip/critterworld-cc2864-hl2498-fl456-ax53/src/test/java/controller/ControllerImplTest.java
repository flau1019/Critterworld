package controller;

import cms.util.maybe.NoMaybeValue;
import controller.ControllerFactory;
import controller.DeterministicHexInformation.CritterHex;

import java.io.PrintStream;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import model.ReadOnlyWorld;
import org.junit.jupiter.api.Test;

public class ControllerImplTest {

    @Test
    public void testPrint() {
        Controller controller = ControllerFactory.getConsoleController();
        controller.loadWorld("src/test/resources/A5files/examples/world.txt", true, true);
        PrintStream out = System.out;
        controller.printWorld(out);
    }

//    public void arraytoHex(){
//        // 15 10 grid into standardized 7 by 10
//        int[][] world = {
//                {71, 66 ,72, 67, 73, 68, 74, 69, 75, 70},
//                {61, 56 ,62, 57, 63, 58, 64, 59, 65, 60},
//                {51, 46 ,52, 47, 53, 48, 54, 49, 55, 50},
//                {41, 36 ,42, 37, 43, 38, 44, 39, 45, 40},
//                {31, 26 ,32, 27, 33, 28, 34, 29, 35, 30}, //this took me so long
//                {21, 16 ,22, 17, 23, 18, 24, 19, 25, 20},
//                {11,  6 ,12,  7, 13,  8, 14,  9, 15, 10},
//                { 1,  0 , 2,  0,  3,  0,  4,  0,  5,  0}, };
//        Controller controller = ControllerFactory.getConsoleController();
//        controller.arraytohex(world);
//        //should be printing out a hex grid in numerical order
//    }

    @Test
    public void testRandomWorld() {
        ControllerImpl controller = (ControllerImpl) ControllerFactory.getConsoleController();
        controller.newWorld();
        ReadOnlyWorld world = controller.getReadOnlyWorld();
        System.out.println(controller.getWorld().getMapCol());
    }

    public void printArray(Object[][] o){
        for(int i = 0; i < o.length; i++){
            for(int j= 0; j<o[i].length; j++) {
                if(o[i][j].equals("")){
                    System.out.print("- ");
                }
                else if(o[i][j] instanceof Integer) {
                    System.out.print(o[i][j] + " ");
                }
                else{
                    System.out.print("c ");
                }
                
            }
            System.out.println("");
        }
    }
}
