package controller;

import console.CritterWorldReader;
import model.Critter;
import model.CritterWorldImpl;
import model.ReadOnlyCritter;
import model.ReadOnlyCritterImpl;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReadOnlyCritterTest {

    ReadOnlyCritter read = new Critter();
    @Test
    public void critterTest() {

    }
}
