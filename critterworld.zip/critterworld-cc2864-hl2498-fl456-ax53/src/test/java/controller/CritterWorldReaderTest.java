package controller;

import console.CritterWorldReader;
import model.Critter;
import model.CritterWorldImpl;
import model.ReadOnlyCritter;
import model.ReadOnlyWorld;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;

public class CritterWorldReaderTest {
    static final String sep = File.separator;
    
    @Test
    public void critterTest() {
        String path="src"+sep+"test"+sep+"resources"+sep+"A5files"+sep+"examples"+sep;
        Critter c1 = CritterWorldReader.readCritter(path + "example-critter.txt");
        Critter c2 = CritterWorldReader.readCritter(path + "example-critter-weird.txt");
        assertEquals(c1, c2);

        try {
            Critter c3 = CritterWorldReader.readCritter(path + "example-critter-broken.txt");
            assertEquals("ILLEGAL CRITTER!!!!", c3.getSpecies());
            assertEquals(10, c3.getMemory()[0]);
            assertEquals(8, c3.getMemory()[4]);
            CritterWorldReader.readCritter(path + "this file doesnt exist");
        } catch (Exception e) {
            fail("Reading an invalid/nonexistent file should not throw an exception.");
        }
    }

    @Test
    public void worldTest() {
        String path="src"+sep+"test"+sep+"resources"+sep+"A5files"+sep+"examples"+sep;
        CritterWorldImpl c = CritterWorldReader.readWorld(path + "world.txt", false, false);
        System.out.println("test");
    }

    @Test
    public void critterReaderTest() {
        Controller controller = ControllerFactory.getConsoleController();
        controller.loadWorld("src/test/resources/A5files/examples/world.txt", true, true);
        ReadOnlyWorld world = controller.getReadOnlyWorld();
        ReadOnlyCritter critter = (ReadOnlyCritter) world.getReadOnlyCritter(2, 5);
    }
}
