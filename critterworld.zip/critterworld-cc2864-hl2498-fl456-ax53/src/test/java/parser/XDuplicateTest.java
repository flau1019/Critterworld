package parser;

import ast.*;
import static org.junit.jupiter.api.Assertions.*;
import ast.Mutate.Duplicate;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import parse.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class XDuplicateTest {
    Duplicate dupe = new Duplicate();
    HPrintAst printer = new HPrintAst();
    @RepeatedTest(1000)
    public void canDuplicateRandom () throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        File duplicated = new File("src/test/resources/files/mutatedPrograms/duplicated.txt");
        StringBuilder sb = new StringBuilder();
        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program = (ProgramImpl) parser.parse(r2);

        dupe.apply(mutant, mutant);

        for (Node child: mutant.getChildren()){
            if (child instanceof Rule rule){
                dupe.apply(mutant, rule);
                assertNotEquals(mutant, program);
            }
        }
        try (FileWriter fileWriter = new FileWriter(duplicated)) {
            mutant.prettyPrint(sb);
            fileWriter.write(sb.toString());

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        assertNotEquals(program, mutant);
        assertNotEquals(program.size(), mutant.size());
        assertNotEquals(program.allNodes, mutant.allNodes);
        assertTrue(program.classInv());
    }

    @RepeatedTest(1000)
    public void swapIsParsableRand() throws IOException, SyntaxError{
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        File duplicated = new File("src/test/resources/files/mutatedPrograms/duplicated.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();

        dupe.apply(mutant, mutant);

        for (Node child: mutant.getChildren()){
            if (child instanceof Rule rule){
                dupe.apply(mutant, rule);
            }
        }

        try (FileWriter fileWriter = new FileWriter(duplicated)) {
            mutant.prettyPrint(sb);

            fileWriter.write(sb.toString());

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        InputStream in1 = new FileInputStream(duplicated);
        Reader r1 = new BufferedReader(new InputStreamReader(in1));
        Parser parser1 = ParserFactory.getParser();

        try{
            ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);
        } catch (SyntaxError e){
            e.printStackTrace();
            fail("could not parse");
        }
    }
}
