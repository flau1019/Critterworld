package parser;

import ast.Mutate.Transform;
import ast.Node;
import ast.ProgramImpl;
import cms.util.maybe.NoMaybeValue;
import exceptions.SyntaxError;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import parse.Parser;
import parse.ParserFactory;
import java.util.Random;

import java.io.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class XTransformTest {
    Transform transform = new Transform();

    @RepeatedTest(10000)
    public void applyTransform() throws SyntaxError, NoMaybeValue, FileNotFoundException {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/TransformTest");

        Reader read = new BufferedReader(new InputStreamReader(in));

        Parser parser = ParserFactory.getParser();

        ProgramImpl program = (ProgramImpl) parser.parse(read);

        Random random = new Random();
        List<Node> nodeList = program.getChildren();
        List<Node> transformList = nodeList.get(random.nextInt(nodeList.size())).getChildren();

        int index = random.nextInt(transformList.size());
        Node n = transformList.get(index);

        if (transform.canApply(transform, n)) {
            program = (ProgramImpl) transform.apply(program, n).get();
        } else {
            try {
                program = (ProgramImpl) transform.apply(program, n).get();
                fail();
            } catch (NoMaybeValue ignored) {}
        }

        StringBuilder builder = new StringBuilder();
        assertEquals(n.getClass(), transformList.get(index).getClass());
        System.out.println(program.prettyPrint(builder).toString());
        assertTrue(program.classInv());
    }
}
