package parser;

import ast.*;

import java.io.*;
import java.util.*;

import ast.ProgramImpl;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import parse.Parser;
import parse.ParserFactory;

import static org.junit.jupiter.api.Assertions.*;

public class AstTest {
    HPrintAst printer = new HPrintAst();

    @Test
    public void astPrint() throws SyntaxError {
        InputStream in = ClassLoader.getSystemResourceAsStream("files/validPrograms/randProgram.txt");
        InputStream in1 = ClassLoader.getSystemResourceAsStream("files/validPrograms/simpleTestProgram");

        assert in != null;
        assert in1!= null;
        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in1));

        Parser parser = ParserFactory.getParser();
        Parser parser1 = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);

        StringBuilder sb = new StringBuilder();

        printer.printAST(program);
        printer.printAST(program1);
        System.out.println(program1.prettyPrint(sb));
    }

    @RepeatedTest(1000)
    public void testParents() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);

        testParent(program);
    }

    @Test
    public void ASTSizeTest() throws SyntaxError, FileNotFoundException {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/exampleRules.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        int numNodes =1;
        for (ArrayList<AbstractNode> nodeList : program.allNodes.values()){
            numNodes += nodeList.size();
        }
        assertEquals(numNodes, program.size());
    }


    @RepeatedTest(1000)
    public void randASTSizeTest() throws SyntaxError, IOException {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        int numNodes =1;
        for (ArrayList<AbstractNode> nodeList : program.allNodes.values()){
            numNodes += nodeList.size();
        }
        assertEquals(numNodes, program.size());
    }

    @Test
    public void compareTrees() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in1 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in1));

        Parser parser = ParserFactory.getParser();
        Parser parser1 = ParserFactory.getParser();

        ProgramImpl program = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);
        assertEquals(program1, program);
    }

    @RepeatedTest(1000)
    public void compareTreesRandom() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in1 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in1));

        Parser parser = ParserFactory.getParser();
        Parser parser1 = ParserFactory.getParser();

        ProgramImpl program = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);
        assertEquals(program, program1);
    }


    private void testParent(Node node) {
        List<Node> children = node.getChildren();
        if (node instanceof Rule rule) {
            children = rule.getCommands();
            for (Node child : children) {
                assertEquals(child.getParentNode(), node);
                testParent(child);
            }

            Node cond = rule.getCond();
            assertEquals(cond.getParentNode(), node);
            testParent(cond);
        } else {
            if (children != null && !children.isEmpty()) {
                for (Node child : children) {
                    assertEquals(child.getParentNode(), node);
                    testParent(child);
                }
            }
        }
    }
}
