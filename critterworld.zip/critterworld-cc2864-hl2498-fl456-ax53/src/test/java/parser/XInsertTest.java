package parser;

import ast.Mutate.*;
import ast.Node;
import ast.ProgramImpl;

import static org.junit.jupiter.api.Assertions.*;

import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;

import parse.Parser;
import parse.ParserFactory;

import java.io.*;
import java.util.*;

public class XInsertTest {
    Random random = new Random();
    Insert insert = new Insert();

    @RepeatedTest(10000)
    public void testInsert() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();
        Parser parser1 = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program = (ProgramImpl) parser1.parse(r1) ;

        insert.apply(mutant, mutant.nodeAt(4));
        assertNotEquals(program.size(), mutant.size());
        assertNotEquals(program.allNodes, mutant.allNodes);
        assertNotEquals(program, mutant);
    }

    @RepeatedTest(10000)
    public void testInsertAll() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();
        Parser parser1 = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program = (ProgramImpl) parser1.parse(r1);

        for (int i = 0; i < program.size(); i++) {
            insert.apply(mutant, mutant.nodeAt(i));
        }

        assertNotEquals(program.size(), mutant.size());
        assertNotEquals(program.allNodes, mutant.allNodes);
        assertNotEquals(program, mutant);
        assertTrue(mutant.classInv());
    }

    @RepeatedTest(10000)
    public void insertRand() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program = (ProgramImpl) parser.parse(r2);

        int size = mutant.size();
        for (int i=0; i<30; i++){
            insert.apply(mutant, mutant.nodeAt(random.nextInt(size)));
        }
        assertNotEquals(program.size(), mutant.size());
        assertNotEquals(program.allNodes, mutant.allNodes);
        assertNotEquals(program, mutant);
        assertTrue(mutant.classInv());
    }
}

