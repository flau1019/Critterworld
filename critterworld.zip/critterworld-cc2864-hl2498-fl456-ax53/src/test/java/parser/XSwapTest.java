package parser;

import ast.Mutate.*;
import ast.*;
import static org.junit.jupiter.api.Assertions.*;

import cms.util.maybe.Maybe;
import cms.util.maybe.NoMaybeValue;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import parse.Parser;
import parse.ParserFactory;

import java.io.*;
import java.util.*;


public class XSwapTest {
    Swap swapMutate = new Swap();
    @Test
    public void applySwap() throws SyntaxError, NoMaybeValue, FileNotFoundException {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();

        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r2);

        swapMutate.apply(mutant, mutant.nodeAt(2)).get();

        assertTrue(compareAst(mutant, program1));
        assertNotEquals(mutant, program1);
        assertEquals(mutant.size(), program1.size());
        assertTrue(compareAllNodes(mutant.allNodes, program1.allNodes));
    }

    @Test
    public void canSwap() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");
        InputStream in1 = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");


        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r1 = new BufferedReader(new InputStreamReader(in1));

        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r1);

        swapAllNodes(program, program);

        assertNotEquals(program, program1);
        assertEquals(program.size(), program1.size());
        assertTrue(compareAllNodes(program.allNodes, program1.allNodes));
    }


    @RepeatedTest(1000)
    public void canSwapRandom() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));

        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);

        swapAllNodes(program, program);
    }

    @RepeatedTest(1000)
    public void swapReturnsValidRand() throws IOException, SyntaxError{
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);

        InputStream in1 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r1 = new BufferedReader(new InputStreamReader(in1));
        Parser parser1 = ParserFactory.getParser();
        ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);

        swapAllNodes(mutant, mutant);

        assertTrue(compareAst(mutant, program1));
        assertNotEquals(mutant, program1);
        assertEquals(mutant.size(), program1.size());
        assertTrue(compareAllNodes(mutant.allNodes, program1.allNodes));
    }
    @RepeatedTest(1000)
    public void swapIsParsableRand() throws IOException, SyntaxError{
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        File swapped = new File("src/test/resources/files/mutatedPrograms/swap.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();

        swapAllNodes(mutant, mutant);

        try (FileWriter fileWriter = new FileWriter(swapped)) {
            mutant.prettyPrint(sb);

            fileWriter.write(sb.toString());

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        InputStream in1 = new FileInputStream(swapped);
        Reader r1 = new BufferedReader(new InputStreamReader(in1));
        Parser parser1 = ParserFactory.getParser();

        try{
            ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);
        } catch (SyntaxError e){
            e.printStackTrace();
            fail("could not parse");
        }
    }


    private boolean compareAllNodes(HashMap<Class<? extends Node>, ArrayList<AbstractNode>> m, HashMap<Class<? extends Node>, ArrayList<AbstractNode>> p){
        for (Class<? extends Node> classType: m.keySet()){
            if (m.get(classType).size()!= p.get(classType).size()){
                return false;
            }
        }
        return true;
    }


    private boolean compareAst(ProgramImpl m, ProgramImpl p){
        if (!(m.getChildren().size() == p.getChildren().size())) return false;
        for (Node mChild: m.getChildren()){
            for (Node child: p.getChildren()){
                assertEquals(mChild.getParentNode().getToken(), child.getParentNode().getToken());
            }
        }
        return true;
    }

    private void swapAllNodes(ProgramImpl program, Node node) {
        Set<Node> visited = new HashSet<>();
        swapChildrenHelper(program, node, visited);
    }

    private void swapChildrenHelper(ProgramImpl program, Node node, Set<Node> visited) {
        if (!visited.add(node)) {
            return;
        }
        Maybe<Program> mutate = swapMutate.apply(program, node);

        if (!node.getChildren().isEmpty()) {
            List<Node> children = new ArrayList<>(node.getChildren());
            for (Node child : children) {
                swapChildrenHelper(program, child, visited);
            }
        }
    }
}
