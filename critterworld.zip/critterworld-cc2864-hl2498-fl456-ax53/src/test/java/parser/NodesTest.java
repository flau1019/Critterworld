package parser;
// Nodes test in this package because it doesn't work if this file locates in \nodes

import ast.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import parse.TokenType;

import java.util.ArrayList;

public class NodesTest {

    @Test
    void Action(){
        Action test = new Action(TokenType.ATTACK);

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("attack", print);

        Action cloned = (Action) test.clone();
        assertTrue(cloned.equals(test));
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.ACTION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(1, test.size());
    }

    @Test
    void BinaryNumeric(){
        BinaryNumeric test = new BinaryNumeric(TokenType.MUL, new Numeric(0), new Numeric(-1));

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("0*-1", print);

        BinaryNumeric cloned = (BinaryNumeric) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.EXPRESSION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(3, test.size());

        assertEquals(0, test.getValue());

        test = new BinaryNumeric(TokenType.MUL, new Numeric(1), new Numeric(-1));
        assertEquals(-1, test.getValue());
        test = new BinaryNumeric(TokenType.MUL, new Numeric(2), new Numeric(5));
        assertEquals(10, test.getValue());
        test = new BinaryNumeric(TokenType.MUL, new Numeric(10), new Numeric(0));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.MINUS, new Numeric(0), new Numeric(-1));
        assertEquals(1, test.getValue());
        test = new BinaryNumeric(TokenType.MINUS, new Numeric(1), new Numeric(2));
        assertEquals(-1, test.getValue());
        test = new BinaryNumeric(TokenType.DIV, new Numeric(0), new Numeric(0));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.DIV, new Numeric(10), new Numeric(0));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.DIV, new Numeric(1), new Numeric(1));
        assertEquals(1, test.getValue());
        test = new BinaryNumeric(TokenType.DIV, new Numeric(4), new Numeric(3));
        assertEquals(1, test.getValue());
        test = new BinaryNumeric(TokenType.PLUS, new Numeric(10), new Numeric(0));
        assertEquals(10, test.getValue());
        test = new BinaryNumeric(TokenType.PLUS, new Numeric(10), new Numeric(10));
        assertEquals(20, test.getValue());
        test = new BinaryNumeric(TokenType.PLUS, new Numeric(0), new Numeric(0));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.MOD, new Numeric(10), new Numeric(0));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.MOD, new Numeric(10), new Numeric(2));
        assertEquals(0, test.getValue());
        test = new BinaryNumeric(TokenType.MOD, new Numeric(10), new Numeric(3));
        assertEquals(1, test.getValue());
    }

    @Test
    void BinaryOp(){
        BinaryOp test = new BinaryOp(TokenType.AND,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)),
                new BinaryRel(TokenType.EQ, new Numeric(-1), new Numeric(-1)));

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("0 = 0 and -1 = -1", print);

        BinaryOp cloned = (BinaryOp) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.CONDITION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(7, test.size());

        assertEquals(true, test.getValue());
        test = new BinaryOp(TokenType.AND,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)));
        assertEquals(false, test.getValue());
        test = new BinaryOp(TokenType.AND,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)),
                new BinaryRel(TokenType.EQ, new Numeric(1), new Numeric(0)));
        assertEquals(false, test.getValue());
        test = new BinaryOp(TokenType.AND,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)));
        assertEquals(false, test.getValue());
        test = new BinaryOp(TokenType.OR,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)));
        assertEquals(true, test.getValue());
        test = new BinaryOp(TokenType.OR,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)));
        assertEquals(true, test.getValue());
        test = new BinaryOp(TokenType.OR,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)));
        assertEquals(true, test.getValue());
        test = new BinaryOp(TokenType.OR,
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)),
                new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1)));
        assertEquals(false, test.getValue());
    }

    @Test
    void BinaryRel(){
        BinaryRel test = new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0));

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("0 = 0", print);

        BinaryRel cloned = (BinaryRel) test.clone();
        assertEquals(cloned, test);
        assertFalse(cloned == test);

        assertEquals(NodeCategory.CONDITION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(3, test.size());

        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(1));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.NE, new Numeric(0), new Numeric(1));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.NE, new Numeric(1), new Numeric(1));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.LT, new Numeric(0), new Numeric(0));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.LT, new Numeric(10), new Numeric(1));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.LT, new Numeric(5), new Numeric(9));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.LE, new Numeric(0), new Numeric(0));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.LE, new Numeric(10), new Numeric(1));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.LE, new Numeric(5), new Numeric(9));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.GE, new Numeric(0), new Numeric(0));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.GE, new Numeric(10), new Numeric(1));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.GE, new Numeric(5), new Numeric(9));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.GT, new Numeric(0), new Numeric(0));
        assertEquals(false, test.getValue());
        test = new BinaryRel(TokenType.GT, new Numeric(10), new Numeric(1));
        assertEquals(true, test.getValue());
        test = new BinaryRel(TokenType.GT, new Numeric(5), new Numeric(9));
        assertEquals(false, test.getValue());
    }

    @Test
    void BinaryUpdate(){
        BinaryUpdate test = new BinaryUpdate(new MemGet(new Numeric(0)), new Numeric(0));

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("MEMSIZE := 0", print);

        BinaryUpdate cloned = (BinaryUpdate) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.UPDATE, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(4, test.size());
    }

    @Test
    void MemGet(){
        MemGet test = new MemGet(new Numeric(0));

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("MEMSIZE", print);

        MemGet cloned = (MemGet) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.EXPRESSION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(2, test.size());
    }

    @Test
    void Rule(){
        ArrayList<Node> argu = new ArrayList<>();
        argu.add(new Action(TokenType.ATTACK));
        Rule test = new Rule(new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)),
                argu);

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("0 = 0 --> attack", print);

        Rule cloned = (Rule) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.RULE, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(5, test.size());

        // add more commands
        argu.add(new BinaryUpdate(new MemGet(new Numeric(0)), new Numeric(1)));
        // illegal command (no more than 1 action per rule)
        argu.add(new Action(TokenType.SERVE, new Numeric(1)));
        try {
            test = new Rule(new BinaryRel(TokenType.EQ, new Numeric(0), new Numeric(0)), argu);
            fail(); // should be throwing exception if invalid input is given
        } catch (IllegalArgumentException ignored) {}
    }

    @Test
    void Sensor(){
        Sensor test = new Sensor(TokenType.SMELL);

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("smell", print);

        Sensor cloned = (Sensor) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.EXPRESSION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(1, test.size());

        Sensor test2 = new Sensor(TokenType.RANDOM, new Numeric(5));
        assertEquals(2, test2.size());
    }

    @Test
    void Numeric(){
        Numeric test = new Numeric(0);

        String print = test.prettyPrint(new StringBuilder()).toString();
        assertEquals("0", print);

        Numeric cloned = (Numeric) test.clone();
        assertEquals(cloned, test);
        assertNotSame(cloned, test);

        assertEquals(NodeCategory.EXPRESSION, test.getCategory());

        assertTrue(test.classInv());

        assertEquals(1, test.size());

        assertEquals(0, test.getValue());
    }

    @Test
    void NodeAt() {
        ArrayList<Rule> arr = new ArrayList<>();
        ArrayList<Node> commands = new ArrayList<>();
        commands.add(new Action(TokenType.FORWARD));
        commands.add(new BinaryUpdate(
                new MemGet(new Numeric(5)),
                new BinaryNumeric(TokenType.MUL, new Numeric(3), new Sensor(TokenType.SMELL)))
        );
        arr.add(new Rule(
                new BinaryOp(
                        TokenType.AND,
                        new BinaryRel(TokenType.EQ, new Numeric(1), new Numeric(1)),
                        new BinaryRel(TokenType.LE, new Numeric(-100), new Numeric(2))
                ),
                commands
        ));
        ProgramImpl program = new ProgramImpl(arr);

        /*
        Program 0
        - Rule 1
        -- BinaryOp (and) 2
        --- BinaryRel (=) 3
        ---- Numeric 1 4
        ---- Numeric 1 5
        --- BinaryRel (<=) 6
        ---- Numeric -100 7
        ---- Numeric 2 8
        -- Action (forward) 9
        -- BinaryUpdate 10
        --- MemGet 11
        ---- Numeric 5 12
        --- BinaryNumeric (*) 13
        ---- Numeric 3 14
        ---- Sensor (smell) 15
         */

        assertEquals(program.nodeAt(0), program);
        assertEquals(program.nodeAt(1), new Rule(new BinaryOp(
                TokenType.AND,
                new BinaryRel(TokenType.EQ, new Numeric(1), new Numeric(1)),
                new BinaryRel(TokenType.LE, new Numeric(-100), new Numeric(2))
        ), commands));
        assertEquals(program.nodeAt(9), commands.getFirst());
        assertEquals(program.nodeAt(10), commands.get(1));
        assertEquals(program.nodeAt(7), new Numeric(-100));
    }
}