package parser;
import ast.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Random;
import java.util.List;

public class HPrintAst {

    /**
     * Prints the AST starting from the given ProgramImpl node.
     *
     * @param program The root of the AST to print.
     */
    public void printAST(ProgramImpl program) {
        printAstLevel(program, 0);
    }

    /**
     * Recursively prints the AST nodes with indentation representing their level in the tree.
     *
     * @param node  The current node to print.
     * @param level The current level in the tree (used for indentation).
     */
    private void printAstLevel(Node node, int level) {
        if (node == null) return;

        String indent = "    ".repeat(level);
        System.out.print(indent + "- ");
        System.out.println(node.printNode());

        if (node instanceof Rule ruleNode) {

            printAstLevel(ruleNode.getCond(), level + 1);

            for (Node commandNode : ruleNode.getCommands()) {
                printAstLevel(commandNode, level + 1);
            }
        } else {
            List<Node> children = node.getChildren();
            if (children != null && !children.isEmpty()) {
                for (Node child : children) {
                    printAstLevel(child, level + 1);
                }
            }
        }
    }
}
