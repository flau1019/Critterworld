package parser;

import ast.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import ast.ProgramImpl;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import parse.Parser;
import parse.ParserFactory;

import static org.junit.jupiter.api.Assertions.*;

/** This class contains tests for the Critter parser. */
public class ParserTest {
    /** Checks that a valid critter program is not {@code null} when parsed. */
    @Test
    public void testProgramIsNotNull() throws SyntaxError {
        InputStream in = ClassLoader.getSystemResourceAsStream("files/randomProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();
        System.out.println(program.prettyPrint(sb));

        assertNotNull(program, "A valid critter program should not be null.");
    }

    @Test
    public void testProgramNodes() throws SyntaxError, IOException {
        Map<Class<? extends Node>, Integer> expectedCounts = new HashMap<>();
        expectedCounts.put(MemGet.class, 8);
        expectedCounts.put(Numeric.class, 26);
        expectedCounts.put(BinaryRel.class, 10);
        expectedCounts.put(BinaryOp.class, 4);
        expectedCounts.put(BinaryNumeric.class, 4);
        expectedCounts.put(BinaryUpdate.class, 1);
        expectedCounts.put(Action.class, 5);
        expectedCounts.put(Rule.class, 6);
        expectedCounts.put(Sensor.class, 4);

        InputStream in = ClassLoader.getSystemResourceAsStream("files/draw_critter.txt");
        assert in != null;
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        program.allNodes.forEach((nodeClass, nodes) -> {
            Integer expectedCount = expectedCounts.get(nodeClass);
                assertEquals(nodes.size(), expectedCount.intValue());
        });
        in.close();
    }
    @RepeatedTest(1000)
    public void testRandomProgram() throws SyntaxError, IOException {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);

        for (Class<? extends Node> nodeClass: program.allNodes.keySet()){
            System.out.println(nodeClass+": "+program.allNodes.get(nodeClass).size() + ", ");
        }

        System.out.println(ec);
        program.allNodes.forEach((nodeClass, nodes) -> {
            Integer expectedCount = ec.get(nodeClass);
            assertEquals(nodes.size(), expectedCount.intValue());
        });
    }
    @Test
    public void testInvalidPrograms() throws IOException {
        File dir = new File("src/test/resources/files/faultyPrograms");
        File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));

        assert files != null;
        for (File file : files) {
            boolean exceptionThrown = false;
            try (InputStream in = new FileInputStream(file);
                 Reader r = new BufferedReader(new InputStreamReader(in))) {
                Parser parser = ParserFactory.getParser();
                ProgramImpl p = (ProgramImpl) parser.parse(r);
                fail(file.getName());
            } catch (Exception e) {
                exceptionThrown = true;
            }
            assertTrue(exceptionThrown);
        }
    }

    @Test
    public void parseRuleWithSpaces() throws SyntaxError {
        InputStream in = ClassLoader.getSystemResourceAsStream("files/validPrograms/exampleRules.txt");
        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl program = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();
        System.out.println(program.prettyPrint(sb));

        assertNotNull(program, "A valid critter program should not be null.");
    }
}

