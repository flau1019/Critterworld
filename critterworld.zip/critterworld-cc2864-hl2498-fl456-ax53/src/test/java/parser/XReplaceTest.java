package parser;

import ast.Mutate.*;
import ast.*;
import static org.junit.jupiter.api.Assertions.*;
import cms.util.maybe.Maybe;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import parse.Parser;
import parse.ParserFactory;
import java.io.*;
import java.util.*;

public class XReplaceTest {
    Replace replace = new Replace();
    Random random = new Random();
    @Test
    public void basicReplace() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();

        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r2);

        for (int i =1; i< mutant.size(); i++){
            Node toReplace = mutant.nodeAt(i);
            Maybe<Program> p = replace.apply(mutant, toReplace);
            if (p.isPresent()){
                assertNotEquals(mutant, program1);
                assertFalse(contains(toReplace, mutant.allNodes));
            }
        }
    }
    @RepeatedTest(1000)
    public void replaceRandom() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();

        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r2);

        for (int i =1; i< 20; i++){
            int numNodes = mutant.size();
            Node toReplace = mutant.nodeAt(random.nextInt(numNodes));
            replace.apply(mutant, toReplace);
        }
        assertNotEquals(mutant, program1);
    }
    @RepeatedTest(1000)
    public void parseReplacedRandom() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        File replaced = new File("src/test/resources/files/mutatedPrograms/replaced.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();

        for (int i =1; i< 20; i++){
            int numNodes = mutant.size();
            Node toReplace = mutant.nodeAt(random.nextInt(numNodes));
            replace.apply(mutant, toReplace);
        }

        try (FileWriter fileWriter = new FileWriter(replaced)) {
            mutant.prettyPrint(sb);

            fileWriter.write(sb.toString());
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        InputStream in1 = new FileInputStream(replaced);
        Reader r1 = new BufferedReader(new InputStreamReader(in1));
        Parser parser1 = ParserFactory.getParser();
        StringBuilder st = new StringBuilder();
        StringBuilder sk = new StringBuilder();

        try{
            ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);

        } catch (SyntaxError e){
            e.printStackTrace();
            fail("could not parse");
        }
    }



    private boolean contains(Node node, HashMap<Class<? extends Node>, ArrayList<AbstractNode>> allNodes) {
        boolean nodeFound = false;
        for (ArrayList<AbstractNode> nodeList : allNodes.values()) {
            if (listContains(nodeList, node)) {
                nodeFound = true;
                break;
            }
        }
        if (!nodeFound) {
            return false;
        }
        for (Node child : node.getChildren()) {
            if (!contains(child, allNodes)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Override of the ArrayList.contains method to use == instead of .equals to check
     * if a reference to the node is present.
     * @param nodeList list to search.
     * @param node node to search for.
     * @return whether a reference to node is present in nodeList.
     */
    private boolean listContains(ArrayList<AbstractNode> nodeList, Node node) {
        for (Node n : nodeList) {
            if (n == node) {
                return true;
            }
        }
        return false;
    }


}
