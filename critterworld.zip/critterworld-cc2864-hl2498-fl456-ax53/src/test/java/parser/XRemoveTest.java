package parser;

import ast.Mutate.*;
import ast.*;
import static org.junit.jupiter.api.Assertions.*;
import cms.util.maybe.Maybe;
import exceptions.SyntaxError;
import model.HGenRandProg;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import parse.Parser;
import parse.ParserFactory;
import java.io.*;
import java.util.*;

public class XRemoveTest {
    Remove remove = new Remove();
    HPrintAst printer = new HPrintAst();
    @Test
    public void basicRemove() throws FileNotFoundException, SyntaxError {
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/simpleTestProgram1");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();

        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r2);

        for (int i =1; i< mutant.size(); i++){
            Node toRemove = mutant.nodeAt(i);
            if (toRemove instanceof ProgramImpl || (toRemove instanceof Rule && mutant.getChildren().size()==1)){
                remove.apply(mutant, toRemove);
                assertEquals(program1, mutant);
                assertTrue(mutant.allNodes.containsKey(toRemove.getClass()));
            }
            else{
                Maybe<Program> p = remove.apply(mutant, toRemove);
                if (p.isPresent()){
                    assertFalse(contains(toRemove, mutant.allNodes));
                }
            }
        }
    }

    @RepeatedTest(1000)
    public void removeRandom() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        InputStream in2 = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Reader r2 = new BufferedReader(new InputStreamReader(in2));

        Parser parser = ParserFactory.getParser();

        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        ProgramImpl program1 = (ProgramImpl) parser.parse(r2);

        for (int i =1; i< mutant.size(); i++){
            Node toRemove = mutant.nodeAt(i);
            if (toRemove instanceof ProgramImpl || (toRemove instanceof Rule && mutant.getChildren().size()==1)){
                remove.apply(mutant, toRemove);
                assertEquals(program1, mutant);
                assertTrue(mutant.allNodes.containsKey(toRemove.getClass()));
            }
            else{
                Maybe<Program> p = remove.apply(mutant, toRemove);
                if (p.isPresent()){
                    assertFalse(contains(toRemove, mutant.allNodes));
                }
            }
        }
    }

    @RepeatedTest(1000)
    public void canParseRemove() throws IOException, SyntaxError {
        Map<Class<? extends Node>, Integer> ec = new HashMap<>();
        HGenRandProg.genRandProgram(ec);
        InputStream in = new FileInputStream("src/test/resources/files/validPrograms/randProgram.txt");
        File duplicated = new File("src/test/resources/files/mutatedPrograms/remove.txt");

        Reader r = new BufferedReader(new InputStreamReader(in));
        Parser parser = ParserFactory.getParser();
        ProgramImpl mutant = (ProgramImpl) parser.parse(r);
        StringBuilder sb = new StringBuilder();

        for (int i = 1; i < mutant.size(); i++) {
            remove.apply(mutant, mutant.nodeAt(i));
        }

        try (FileWriter fileWriter = new FileWriter(duplicated)) {
            mutant.prettyPrint(sb);

            fileWriter.write(sb.toString());

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        InputStream in1 = new FileInputStream(duplicated);
        Reader r1 = new BufferedReader(new InputStreamReader(in1));
        Parser parser1 = ParserFactory.getParser();

        try{
            ProgramImpl program1 = (ProgramImpl) parser1.parse(r1);
        } catch (SyntaxError e){
            e.printStackTrace();
            fail("could not parse");
        }
    }

    private boolean contains(Node node, HashMap<Class<? extends Node>, ArrayList<AbstractNode>> allNodes) {
        boolean nodeFound = false;
        for (ArrayList<AbstractNode> nodeList : allNodes.values()) {
            if (listContains(nodeList, node)) {
                nodeFound = true;
                break;
            }
        }
        if (!nodeFound) {
            return false;
        }
        for (Node child : node.getChildren()) {
            if (!contains(child, allNodes)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Override of the ArrayList.contains method to use == instead of .equals to check
     * if a reference to the node is present.
     * @param nodeList list to search.
     * @param node node to search for.
     * @return whether a reference to node is present in nodeList.
     */
    private boolean listContains(ArrayList<AbstractNode> nodeList, Node node) {
        for (Node n : nodeList) {
            if (n == node) {
                return true;
            }
        }
        return false;
    }

}
